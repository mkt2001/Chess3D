class_name ChessData
extends RefCounted
# Lessons, puzzles and the guided game. goal: "any" | "info" | uci prefix(es)

static func lessons():
	return [
		{"cat": "1. Piece Moves", "title": "The King", "text": "The king moves one square in any direction. Protect him - if he is trapped, you lose! Tap the king, then a green dot.", "fen": "8/8/8/8/3K4/8/8/8 w - - 0 1", "goal": "any"},
		{"cat": "1. Piece Moves", "title": "The Rook", "text": "Rooks slide any distance in straight lines. Capture the black pawn on d5.", "fen": "8/8/8/3p4/8/8/8/3R4 w - - 0 1", "goal": "d1d5"},
		{"cat": "1. Piece Moves", "title": "The Bishop", "text": "Bishops slide diagonally and stay on one colour forever. Capture the pawn on f6.", "fen": "8/8/5p2/8/8/2B5/8/8 w - - 0 1", "goal": "c3f6"},
		{"cat": "1. Piece Moves", "title": "The Queen", "text": "The queen = rook + bishop. The strongest piece! Capture the pawn on g7.", "fen": "8/6p1/8/8/3Q4/8/8/8 w - - 0 1", "goal": "d4g7"},
		{"cat": "1. Piece Moves", "title": "The Knight", "text": "Knights jump in an L-shape and can leap over pieces. Capture the pawn on e5.", "fen": "8/8/8/4p3/8/3N4/8/8 w - - 0 1", "goal": "d3e5"},
		{"cat": "1. Piece Moves", "title": "Pawns", "text": "Pawns move forward but CAPTURE diagonally. Capture the pawn on d3.", "fen": "8/8/8/8/8/3p4/4P3/8 w - - 0 1", "goal": "e2d3"},
		{"cat": "1. Piece Moves", "title": "Pawn double step", "text": "From its start square a pawn may advance two squares. Play e2-e4.", "fen": "8/8/8/8/8/8/4P3/8 w - - 0 1", "goal": "e2e4"},
		{"cat": "2. Special Rules", "title": "Castling", "text": "Castling tucks the king to safety and activates a rook. Move the king two squares toward a rook.", "fen": "r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1", "goal": ["e1g1", "e1c1"]},
		{"cat": "2. Special Rules", "title": "En passant", "text": "Black just played d7-d5 next to your pawn. You may capture it as if it moved one square: e5xd6.", "fen": "8/8/8/3pP3/8/8/8/8 w - d6 0 1", "goal": "e5d6"},
		{"cat": "2. Special Rules", "title": "Promotion", "text": "A pawn reaching the last rank becomes any piece - usually a queen. Push e7-e8!", "fen": "8/4P3/8/8/8/8/8/8 w - - 0 1", "goal": "e7e8"},
		{"cat": "3. Winning Ideas", "title": "Back-rank mate", "text": "The black king is boxed in by his own pawns. Deliver checkmate with the rook.", "fen": "6k1/5ppp/8/8/8/8/5PPP/3R2K1 w - - 0 1", "goal": "d1d8"},
		{"cat": "3. Winning Ideas", "title": "Knight fork", "text": "A fork attacks two pieces at once. Check the king AND attack the queen: Ne7+!", "fen": "2q3k1/5ppp/8/3N4/8/8/5PPP/6K1 w - - 0 1", "goal": "d5e7"},
		{"cat": "3. Winning Ideas", "title": "Skewer", "text": "A skewer attacks a valuable piece so it must move, exposing the piece behind it. Play Rh8+!", "fen": "1q2k3/8/8/8/8/8/5PP1/6KR w - - 0 1", "goal": "h1h8"},
		{"cat": "3. Winning Ideas", "title": "Free piece", "text": "Always ask: is anything undefended? The black queen is hanging - take it.", "fen": "4k3/8/8/8/2q5/8/8/4KB2 w - - 0 1", "goal": "f1c4"},
		{"cat": "4. Opening Principles", "title": "Control the centre", "text": "Start with a centre pawn: play e2-e4 or d2-d4 to claim space and free your bishop and queen.", "fen": "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1", "goal": ["e2e4", "d2d4"]},
		{"cat": "4. Opening Principles", "title": "Develop knights", "text": "Bring pieces out quickly. Black's e5 pawn is attacked by Nf3 - develop with tempo!", "fen": "rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR w KQkq e6 0 2", "goal": "g1f3"},
		{"cat": "5. Endgame Lab (vs AI)", "title": "King + Queen vs King", "text": "Practice the basic mate against the computer. Coach hints are ON.", "fen": "8/8/8/4k3/8/8/8/3QK3 w - - 0 1", "practice": true},
		{"cat": "5. Endgame Lab (vs AI)", "title": "King + Rook vs King", "text": "Use the rook and king together to push the enemy king to the edge.", "fen": "8/8/8/4k3/8/8/8/R3K3 w - - 0 1", "practice": true},
		{"cat": "5. Endgame Lab (vs AI)", "title": "King + Pawn vs King", "text": "Escort the pawn to promotion with your king in front.", "fen": "8/8/8/4k3/8/4K3/4P3/8 w - - 0 1", "practice": true},
	]

static func puzzles():
	return [
		{"id": "p1", "title": "Back-rank rook", "fen": "6k1/5ppp/8/8/8/8/5PPP/3R2K1 w - - 0 1", "sol": ["d1d8"], "mate": true, "text": "White to move. Mate in 1."},
		{"id": "p2", "title": "Corner box", "fen": "k7/8/1K6/8/8/8/8/7R w - - 0 1", "sol": ["h1h8"], "mate": true, "text": "White to move. Mate in 1."},
		{"id": "p3", "title": "Queen + King", "fen": "7k/5Q2/6K1/8/8/8/8/8 w - - 0 1", "sol": ["f7g7"], "mate": true, "text": "White to move. Mate in 1."},
		{"id": "p4", "title": "Smothered mate", "fen": "6rk/6pp/8/6N1/8/8/8/6K1 w - - 0 1", "sol": ["g5f7"], "mate": true, "text": "White to move. Mate in 1."},
		{"id": "p5", "title": "Back-rank queen", "fen": "6k1/5ppp/8/8/8/8/5PPP/4Q1K1 w - - 0 1", "sol": ["e1e8"], "mate": true, "text": "White to move. Mate in 1."},
		{"id": "p6", "title": "Royal fork", "fen": "2q3k1/5ppp/8/3N4/8/8/5PPP/6K1 w - - 0 1", "sol": ["d5e7", "g8h8", "e7c8"], "mate": false, "text": "White to move. Win the queen!"},
		{"id": "p7", "title": "Skewer", "fen": "1q2k3/8/8/8/8/8/5PP1/6KR w - - 0 1", "sol": ["h1h8", "e8d7", "h8b8"], "mate": false, "text": "White to move. Win the queen!"},
		{"id": "p8", "title": "Free queen", "fen": "4k3/8/8/8/2q5/8/8/4KB2 w - - 0 1", "sol": ["f1c4"], "mate": false, "text": "White to move. Win material."},
	]

# Morphy vs Duke of Brunswick & Count Isouard, Paris 1858 ("Opera Game"). White moves = even indexes.
static func opera():
	return ["e2e4", "e7e5", "g1f3", "d7d6", "d2d4", "c8g4", "d4e5", "g4f3", "d1f3", "d6e5", "f1c4", "g8f6", "f3b3", "d8e7", "b1c3", "c7c6", "c1g5", "b7b5", "c3b5", "c6b5", "c4b5", "b8d7", "e1c1", "a8d8", "d1d7", "d8d7", "h1d1", "e7e6", "b5d7", "f6d7", "b3b8", "d7b8", "d1d8"]

static func opera_notes():
	return {0: "Claim the centre.", 2: "Develop with a threat on e5.", 4: "Open the centre while ahead in development.", 8: "Recapture and keep developing.", 10: "Bishop aims at the weak f7 square.", 12: "Queen attacks b7 and pins down black.", 16: "Pin the knight to the queen.", 18: "A sacrifice to rip open the king.", 22: "Castle long - bring the rook to the open file.", 24: "Rooks join the attack.", 30: "The queen sacrifice!", 32: "Checkmate - every piece joined the attack."}
