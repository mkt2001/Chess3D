class_name GraphView
extends Control

var data = []
var cur = 0

func _draw():
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.05, 0.07, 0.12, 0.92))
	var mid = size.y * 0.5
	draw_line(Vector2(0, mid), Vector2(size.x, mid), Color(1, 1, 1, 0.2), 2.0)
	if data.size() < 2:
		return
	var pts = PackedVector2Array()
	for i in range(data.size()):
		var x = size.x * float(i) / float(data.size() - 1)
		var v = clampf(float(data[i]), -600.0, 600.0) / 600.0
		pts.append(Vector2(x, mid - v * mid * 0.9))
	draw_polyline(pts, Color("#e8c76a"), 4.0, true)
	var cx = size.x * float(cur) / float(data.size() - 1)
	draw_line(Vector2(cx, 0), Vector2(cx, size.y), Color(0.3, 0.9, 1.0, 0.9), 3.0)
