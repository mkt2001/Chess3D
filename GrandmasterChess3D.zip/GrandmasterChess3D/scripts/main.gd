extends Node
# 3D Grandmaster Chess - app flow, premium UI, game modes, coach, academy.

const GOLD = Color("#e8c76a")
const GOLD2 = Color("#b8892b")
const INK = Color("#0a0e1a")
const PANEL = Color(0.06, 0.08, 0.15, 0.95)
const CARD = Color(0.11, 0.14, 0.25, 0.96)
const TXT = Color("#f2f4fa")
const MUTED = Color("#9aa3bd")
const GREEN = Color("#46d18c")
const RED = Color("#ff5d6c")
const AMBER = Color("#ffb347")

const LV_NAMES = ["Beginner", "Easy", "Normal", "Medium", "Hard", "Expert", "Master", "Grandmaster", "Maximum Strength"]
const LV_ELO = [400, 600, 800, 1000, 1300, 1600, 1900, 2200, 2500]
const STYLES = ["Balanced", "Aggressive", "Defensive", "Tactical", "Positional"]
const TCS = [["Off", 0, 0], ["3+2", 180, 2], ["5+0", 300, 0], ["10+0", 600, 0], ["15+10", 900, 10]]
const FEATURES = [
	["REAL 3D CHESS", "Genuine 3D board and turned pieces. Rotate, zoom, pan - every angle."],
	["AI: BASIC TO GRANDMASTER", "9 strength levels and 5 play styles. Hints, undo and takebacks."],
	["LEARNING ACADEMY", "Learn by doing on the 3D board: moves, rules, tactics, openings, endgames."],
	["AI COACH", "Live feedback after every move, evaluation bar, blunder alerts."],
	["PUZZLES", "Spaced-repetition trainer: missed puzzles return sooner."],
	["PREMIUM THEMES", "8 boards, 6 piece sets, 6 environments. Mix and match freely."],
	["MANY MODES", "vs AI, Coach, 2 Player, Chess960, Blindfold, Guess-the-Move, Endgame Lab."],
	["GAME REVIEW", "Move-by-move AI review with accuracy % and eval graph."],
]

var board3d
var ui
var save = {}
var game
var mode = ""
var screen = "splash"
var human = 1
var level = 5
var style = 0
var tc_idx = 0
var coach_on = false
var hints_on = true
var blind = false
var setup_mode = "ai"
var setup_side = 0
var sel = -1
var targets = []
var last = [-1, -1]
var hint_mv = [-1, -1]
var thinking = false
var over = false
var epoch = 0
var moves_hist = []
var san_hist = []
var fens = []
var clock = [0.0, 0.0]
var inc = 0
var hud = {}
var jobs = []
var sfx = []
var sfx_i = 0
var snd = {}
var lesson_i = 0
var puzzle = null
var puzzle_step = 0
var puzzle_hinted = false
var puzzle_failed = false
var guess_i = 0
var guess_score = 0
var guess_wrong = 0
var analysis = {}
var an_idx = 0
var result_text = ""

func _ready():
	randomize()
	DisplayServer.screen_set_keep_on(true)
	_load()
	board3d = Board3D.new()
	add_child(board3d)
	board3d.square_tapped.connect(_on_square)
	var layer = CanvasLayer.new()
	add_child(layer)
	ui = Control.new()
	layer.add_child(ui)
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.theme = _make_theme()
	_make_sounds()
	game = Chess.new()
	game.reset()
	_apply_skin()
	show_splash()

func _notification(what):
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_back()

# ---------------------------------------------------------------- save
func _load():
	var cf = ConfigFile.new()
	var d = {"rating": 800, "xp": 0, "streak": 0, "day": 0, "games": 0, "wins": 0, "losses": 0, "draws": 0, "board": 0, "piece": 0, "env": 0, "lessons": [], "pbox": {}, "solved": 0, "sound": true}
	if cf.load("user://save.cfg") == OK:
		for k in d.keys():
			d[k] = cf.get_value("p", k, d[k])
	save = d

func _save():
	var cf = ConfigFile.new()
	for k in save.keys():
		cf.set_value("p", k, save[k])
	cf.save("user://save.cfg")

func _touch_streak():
	var day = int(Time.get_unix_time_from_system() / 86400.0)
	if day != save.day:
		save.streak = save.streak + 1 if day - save.day == 1 else 1
		save.day = day

func _add_xp(n):
	save.xp += n
	_touch_streak()
	_save()

func _apply_skin():
	board3d.set_skin(save.board, save.piece, save.env)
	board3d.show_position(game)

# ---------------------------------------------------------------- audio
func _tone(freq, dur, vol, decay, noise):
	var n = int(22050 * dur)
	var data = PackedByteArray()
	data.resize(n * 2)
	for i in range(n):
		var t = float(i) / 22050.0
		var e = exp(-decay * t)
		var s = sin(TAU * freq * t) * e + randf_range(-1.0, 1.0) * noise * e
		data.encode_s16(i * 2, int(clampf(s * vol, -1.0, 1.0) * 32767.0))
	var w = AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = 22050
	w.stereo = false
	w.data = data
	return w

func _make_sounds():
	snd["move"] = _tone(210.0, 0.12, 0.8, 38.0, 0.5)
	snd["cap"] = _tone(130.0, 0.22, 0.9, 22.0, 0.9)
	snd["check"] = _tone(880.0, 0.4, 0.5, 6.0, 0.0)
	snd["win"] = _tone(660.0, 0.8, 0.5, 3.0, 0.0)
	snd["click"] = _tone(1300.0, 0.05, 0.4, 70.0, 0.1)
	snd["bad"] = _tone(150.0, 0.3, 0.5, 8.0, 0.2)
	for i in range(4):
		var p = AudioStreamPlayer.new()
		add_child(p)
		sfx.append(p)

func _play(n):
	if not save.sound:
		return
	var p = sfx[sfx_i % 4]
	sfx_i += 1
	p.stream = snd[n]
	p.play()
	if n == "move" or n == "cap":
		Input.vibrate_handheld(25)

# ---------------------------------------------------------------- UI helpers
func _make_theme():
	var th = Theme.new()
	th.default_font_size = 34
	th.set_color("font_color", "Label", TXT)
	return th

func _sb(col, rad = 28, bc = Color(0, 0, 0, 0), bw = 0, pad = 24):
	var s = StyleBoxFlat.new()
	s.bg_color = col
	s.set_corner_radius_all(rad)
	s.border_color = bc
	s.set_border_width_all(bw)
	s.content_margin_left = pad
	s.content_margin_right = pad
	s.content_margin_top = pad * 0.6
	s.content_margin_bottom = pad * 0.6
	return s

func _lbl(t, sz = 34, col = TXT, al = HORIZONTAL_ALIGNMENT_LEFT):
	var l = Label.new()
	l.text = t
	l.add_theme_font_size_override("font_size", sz)
	l.add_theme_color_override("font_color", col)
	l.horizontal_alignment = al
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l

func _btn(t, cb, kind = "dark", sz = 34, h = 96):
	var b = Button.new()
	b.text = t
	b.custom_minimum_size = Vector2(0, h)
	b.add_theme_font_size_override("font_size", sz)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var bg = CARD
	var fc = TXT
	var bc = Color(1, 1, 1, 0.14)
	if kind == "gold":
		bg = GOLD
		fc = INK
		bc = GOLD2
	elif kind == "ghost":
		bg = Color(0, 0, 0, 0.45)
	elif kind == "red":
		bg = Color("#7a1f2b")
	elif kind == "sel":
		bg = Color("#2a3566")
		bc = GOLD
	b.add_theme_stylebox_override("normal", _sb(bg, 26, bc, 3 if kind == "sel" else 2))
	b.add_theme_stylebox_override("hover", _sb(bg.lightened(0.08), 26, bc, 2))
	b.add_theme_stylebox_override("pressed", _sb(bg.lightened(0.2), 26, bc, 2))
	b.add_theme_stylebox_override("focus", _sb(bg, 26, bc, 2))
	for n in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		b.add_theme_color_override(n, fc)
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(func():
		_play("click")
		cb.call())
	return b

func _vb(sep = 20):
	var v = VBoxContainer.new()
	v.add_theme_constant_override("separation", sep)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return v

func _hb(sep = 16):
	var h = HBoxContainer.new()
	h.add_theme_constant_override("separation", sep)
	h.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return h

func _full(c):
	c.anchor_left = 0.0
	c.anchor_top = 0.0
	c.anchor_right = 1.0
	c.anchor_bottom = 1.0
	c.offset_left = 0.0
	c.offset_top = 0.0
	c.offset_right = 0.0
	c.offset_bottom = 0.0
	return c

func _anchor_top(c, margin = 24, top = 48):
	c.anchor_left = 0.0
	c.anchor_right = 1.0
	c.anchor_top = 0.0
	c.anchor_bottom = 0.0
	c.offset_left = margin
	c.offset_right = -margin
	c.offset_top = top
	c.offset_bottom = top
	c.grow_vertical = Control.GROW_DIRECTION_END

func _anchor_bottom(c, margin = 24, bottom = 48):
	c.anchor_left = 0.0
	c.anchor_right = 1.0
	c.anchor_top = 1.0
	c.anchor_bottom = 1.0
	c.offset_left = margin
	c.offset_right = -margin
	c.offset_top = -bottom
	c.offset_bottom = -bottom
	c.grow_vertical = Control.GROW_DIRECTION_BEGIN

func _margin(c, m):
	var mc = MarginContainer.new()
	for s in ["left", "right", "top", "bottom"]:
		mc.add_theme_constant_override("margin_" + s, m)
	mc.add_child(c)
	return mc

func _clear():
	for c in ui.get_children():
		ui.remove_child(c)
		c.queue_free()
	hud = {}
	ui.modulate.a = 0.0
	create_tween().tween_property(ui, "modulate:a", 1.0, 0.25)

func _panel(col = CARD, rad = 32, pad = 28):
	var p = PanelContainer.new()
	p.add_theme_stylebox_override("panel", _sb(col, rad, Color(1, 1, 1, 0.10), 2, pad))
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return p

func _choice(labels, sel_i, on_pick):
	var fl = HFlowContainer.new()
	fl.add_theme_constant_override("h_separation", 12)
	fl.add_theme_constant_override("v_separation", 12)
	fl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var btns = []
	for i in range(labels.size()):
		var b = _btn(labels[i], func(): pass, "dark", 30, 84)
		b.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
		b.custom_minimum_size = Vector2(190, 84)
		fl.add_child(b)
		btns.append(b)
	var paint = func(cur):
		for j in range(btns.size()):
			var on = (j == cur)
			var bg = Color("#2a3566") if on else CARD
			var bc = GOLD if on else Color(1, 1, 1, 0.14)
			btns[j].add_theme_stylebox_override("normal", _sb(bg, 26, bc, 3 if on else 2))
	paint.call(sel_i)
	for i in range(btns.size()):
		for c in btns[i].pressed.get_connections():
			btns[i].pressed.disconnect(c.callable)
		btns[i].pressed.connect(func():
			_play("click")
			paint.call(i)
			on_pick.call(i))
	return fl

func _gradient_rect(c1, c2, vertical = true):
	var tr = TextureRect.new()
	var gt = GradientTexture2D.new()
	var g = Gradient.new()
	g.colors = PackedColorArray([c1, c2])
	g.offsets = PackedFloat32Array([0.0, 1.0])
	gt.gradient = g
	gt.fill_from = Vector2(0.5, 0.0) if vertical else Vector2(0.0, 0.5)
	gt.fill_to = Vector2(0.5, 1.0) if vertical else Vector2(1.0, 0.5)
	gt.width = 8
	gt.height = 128
	tr.texture = gt
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_SCALE
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return tr

func _demo():
	var c = Chess.new()
	c.reset()
	board3d.show_position(c)
	board3d.set_blind(false)

# ---------------------------------------------------------------- threads
func _start_job(kind, data, ep):
	var t = Thread.new()
	t.start(_job_entry.bind(kind, data))
	jobs.append({"t": t, "kind": kind, "ep": ep})

func _job_entry(kind, d):
	var ai = ChessAI.new()
	var r = {"kind": kind}
	if kind == "ai":
		r["m"] = ai.choose(d.c, d.lvl, d.style)
	elif kind == "hint":
		r["m"] = ai.choose(d.c, 8, 0, 1500)
	elif kind == "eval":
		r["v"] = ai.eval_pos(d.c, 3) * d.c.turn
	elif kind == "coach":
		var c = d.c
		var sc = ai.score_moves(c, 2)
		var bm = -1
		var bs = -2000000
		for m in sc:
			if sc[m] > bs:
				bs = sc[m]
				bm = m
		var ps = sc.get(d.m, bs)
		r["loss"] = mini(bs - ps, 2000)
		r["best_m"] = bm
		r["best"] = c.san(bm) if bm >= 0 else ""
		r["same"] = (bm == d.m)
		r["note"] = ai.hanging_note(c, d.m)
	elif kind == "analyze":
		var losses = []
		var bests = []
		var evals = [0]
		for i in range(d.moves.size()):
			var c = Chess.new()
			c.load_fen(d.fens[i])
			var sc = ai.score_moves(c, d.depth)
			var bm = -1
			var bs = -2000000
			for m in sc:
				if sc[m] > bs:
					bs = sc[m]
					bm = m
			var ps = sc.get(d.moves[i], bs)
			losses.append(mini(bs - ps, 2000))
			bests.append(c.san(bm) if bm >= 0 else "")
			evals.append(ps * c.turn)
		r["losses"] = losses
		r["bests"] = bests
		r["evals"] = evals
	return r

func _process(delta):
	for j in jobs.duplicate():
		if not j.t.is_alive():
			var res = j.t.wait_to_finish()
			jobs.erase(j)
			_on_job(res, j.ep)
	if screen == "game" and not over and TCS[tc_idx][1] > 0 and mode != "endgame":
		var i = 0 if game.turn > 0 else 1
		clock[i] -= delta
		if clock[i] <= 0.0:
			clock[i] = 0.0
			_end_game("timeout")
		_refresh_clock()

func _on_job(res, ep):
	var k = res.kind
	if k == "analyze":
		_show_analysis(res)
		return
	if ep != epoch:
		return
	if k == "ai":
		thinking = false
		if res.m >= 0 and not over:
			_play_move(res.m, true)
	elif k == "hint":
		if res.m >= 0:
			hint_mv = [res.m & 63, (res.m >> 6) & 63]
			_marks()
			if hud.has("msg"):
				hud.msg.text = "Hint: try " + Chess.sq_name(res.m & 63) + " to " + Chess.sq_name((res.m >> 6) & 63)
				hud.msg.add_theme_color_override("font_color", AMBER)
	elif k == "eval":
		if hud.has("eval"):
			hud.eval.value = 100.0 / (1.0 + exp(-float(res.v) / 250.0))
	elif k == "coach":
		_show_coach(res)

func _show_coach(res):
	if not hud.has("msg"):
		return
	var loss = res.loss
	var txt = ""
	var col = GREEN
	if res.same or loss <= 12:
		txt = "Excellent! That's the engine's top choice."
	elif loss <= 40:
		txt = "Good move."
	elif loss <= 100:
		txt = "Inaccuracy. Better was " + res.best + "."
		col = AMBER
	elif loss <= 250:
		txt = "Mistake. " + res.best + " was stronger."
		col = AMBER
	else:
		txt = "Blunder! " + res.best + " was needed."
		col = RED
	if res.best.contains("x") and loss > 40:
		txt += " It wins material."
	elif (res.best.contains("+") or res.best.contains("#")) and loss > 40:
		txt += " It attacks the king."
	if res.note != "" and loss > 40:
		txt += " " + res.note
	hud.msg.text = txt
	hud.msg.add_theme_color_override("font_color", col)
	if loss > 250:
		_play("bad")

# ---------------------------------------------------------------- SPLASH (outside)
func _shade():
	var tr = TextureRect.new()
	var gt = GradientTexture2D.new()
	var g = Gradient.new()
	g.colors = PackedColorArray([Color(0.02, 0.03, 0.07, 0.9), Color(0.02, 0.03, 0.07, 0.0), Color(0.02, 0.03, 0.07, 0.98)])
	g.offsets = PackedFloat32Array([0.0, 0.34, 0.7])
	gt.gradient = g
	gt.fill_from = Vector2(0.5, 0.0)
	gt.fill_to = Vector2(0.5, 1.0)
	gt.width = 8
	gt.height = 256
	tr.texture = gt
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_SCALE
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return _full(tr)

func show_splash():
	_clear()
	screen = "splash"
	mode = "menu"
	board3d.showcase(true)
	_demo()
	ui.add_child(_shade())
	var mc = _margin(_vb(22), 44)
	_full(mc)
	ui.add_child(mc)
	var v = mc.get_child(0)
	v.add_child(_lbl("", 40))
	v.add_child(_lbl("GRANDMASTER", 96, GOLD, HORIZONTAL_ALIGNMENT_CENTER))
	v.add_child(_lbl("3D CHESS", 60, TXT, HORIZONTAL_ALIGNMENT_CENTER))
	v.add_child(_lbl("Real 3D board  -  AI opponents  -  Learning academy", 28, MUTED, HORIZONTAL_ALIGNMENT_CENTER))
	var sp = Control.new()
	sp.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v.add_child(sp)
	var sc = ScrollContainer.new()
	sc.custom_minimum_size = Vector2(0, 300)
	sc.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var hb = _hb(20)
	sc.add_child(hb)
	for f in FEATURES:
		var p = _panel(CARD, 36, 26)
		p.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
		var fv = _vb(10)
		p.add_child(fv)
		var t = _lbl(f[0], 36, GOLD)
		t.custom_minimum_size = Vector2(500, 0)
		fv.add_child(t)
		var d = _lbl(f[1], 29, TXT)
		d.custom_minimum_size = Vector2(500, 0)
		fv.add_child(d)
		hb.add_child(p)
	v.add_child(sc)
	var tw = sc.create_tween().set_loops()
	tw.tween_interval(1.5)
	tw.tween_property(sc, "scroll_horizontal", 3200, 14.0)
	tw.tween_interval(1.0)
	tw.tween_property(sc, "scroll_horizontal", 0, 6.0)
	v.add_child(_btn("ENTER THE ARENA", show_dashboard, "gold", 46, 140))
	v.add_child(_lbl("Works fully offline  -  v1.0", 24, MUTED, HORIZONTAL_ALIGNMENT_CENTER))
	v.add_child(_lbl("", 20))

# ---------------------------------------------------------------- DASHBOARD
func _pill(t):
	var p = PanelContainer.new()
	p.add_theme_stylebox_override("panel", _sb(Color(0, 0, 0, 0.5), 30, GOLD2, 2, 20))
	var l = _lbl(t, 28, GOLD)
	l.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	p.add_child(l)
	p.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	return p

func _swatch(kind, it):
	var holder = CenterContainer.new()
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	holder.custom_minimum_size = Vector2(0, 118)
	if kind == "board":
		var g = GridContainer.new()
		g.columns = 2
		g.add_theme_constant_override("h_separation", 0)
		g.add_theme_constant_override("v_separation", 0)
		for k in range(4):
			var r = ColorRect.new()
			r.custom_minimum_size = Vector2(56, 56)
			r.color = it.l if (k == 0 or k == 3) else it.d
			r.mouse_filter = Control.MOUSE_FILTER_IGNORE
			g.add_child(r)
		holder.add_child(g)
	elif kind == "piece":
		var h = HBoxContainer.new()
		h.add_theme_constant_override("separation", 10)
		for c in [it.w, it.b]:
			var p = Panel.new()
			p.custom_minimum_size = Vector2(84, 84)
			p.add_theme_stylebox_override("panel", _sb(c, 42, GOLD, 3, 0))
			p.mouse_filter = Control.MOUSE_FILTER_IGNORE
			h.add_child(p)
		holder.add_child(h)
	else:
		var gr = _gradient_rect(it.top, it.hor)
		gr.custom_minimum_size = Vector2(170, 110)
		holder.add_child(gr)
	return holder

func _skin_row(title, items, key, kind):
	var box = _vb(12)
	box.add_child(_lbl(title, 30, MUTED))
	var sc = ScrollContainer.new()
	sc.custom_minimum_size = Vector2(0, 252)
	sc.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var hb = _hb(18)
	sc.add_child(hb)
	box.add_child(sc)
	var panels = []
	var paint = func():
		for j in range(panels.size()):
			var on = (save[key] == j)
			panels[j].add_theme_stylebox_override("panel", _sb(CARD, 30, GOLD if on else Color(1, 1, 1, 0.1), 5 if on else 2, 14))
	for i in range(items.size()):
		var w = Control.new()
		w.custom_minimum_size = Vector2(250, 232)
		var p = PanelContainer.new()
		_full(p)
		p.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var v = _vb(8)
		v.mouse_filter = Control.MOUSE_FILTER_IGNORE
		p.add_child(v)
		v.add_child(_swatch(kind, items[i]))
		var nl = _lbl(items[i].n, 26, TXT, HORIZONTAL_ALIGNMENT_CENTER)
		nl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		v.add_child(nl)
		w.add_child(p)
		panels.append(p)
		var ob = Button.new()
		_full(ob)
		ob.flat = true
		ob.focus_mode = Control.FOCUS_NONE
		ob.pressed.connect(func():
			save[key] = i
			_save()
			_apply_skin()
			_play("click")
			paint.call())
		w.add_child(ob)
		hb.add_child(w)
	paint.call()
	return box

func show_dashboard():
	_clear()
	screen = "dash"
	mode = "menu"
	game = Chess.new()
	game.reset()
	board3d.showcase(true)
	board3d.t_look = Vector3(0, 0, 4.3)
	_apply_skin()
	board3d.set_blind(false)
	var sc = ScrollContainer.new()
	_full(sc)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	ui.add_child(sc)
	var col = _vb(0)
	sc.add_child(col)
	var hv = _vb(10)
	hv.add_child(_lbl("GRANDMASTER", 66, GOLD))
	hv.add_child(_lbl("3D CHESS DASHBOARD", 28, MUTED))
	var pr = _hb(12)
	pr.add_child(_pill("Rating " + str(save.rating)))
	pr.add_child(_pill("Level " + str(1 + int(save.xp / 200))))
	pr.add_child(_pill("Streak " + str(save.streak)))
	hv.add_child(pr)
	var head = _margin(hv, 40)
	head.custom_minimum_size = Vector2(0, 760)
	col.add_child(head)
	var sheet = PanelContainer.new()
	var st = _sb(PANEL, 56, Color(1, 1, 1, 0.1), 2, 36)
	st.corner_radius_bottom_left = 0
	st.corner_radius_bottom_right = 0
	sheet.add_theme_stylebox_override("panel", st)
	sheet.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_child(sheet)
	var inner = _vb(28)
	sheet.add_child(inner)
	inner.add_child(_lbl("YOUR STYLE  (tap to apply - mix freely)", 32, GOLD))
	inner.add_child(_skin_row("BOARD THEMES", Skins.boards(), "board", "board"))
	inner.add_child(_skin_row("PIECE SETS", Skins.pieces(), "piece", "piece"))
	inner.add_child(_skin_row("3D ENVIRONMENTS", Skins.envs(), "env", "env"))
	inner.add_child(_lbl("GAME MODES", 32, GOLD))
	var grid = GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 20)
	grid.add_theme_constant_override("v_separation", 20)
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var modes = [
		["Play vs AI", "9 levels, 5 styles", func(): show_setup("ai")],
		["AI Coach Game", "Live feedback + eval bar", func(): show_setup("coach")],
		["2 Players", "Pass and play", func(): start_game("local", {})],
		["Chess960", "Random back rank", func(): show_setup("960")],
		["Blindfold", "Play without pieces", func(): show_setup("blind")],
		["Puzzles", "Spaced repetition", func(): start_puzzle()],
		["Academy", "Learn step by step", func(): show_academy()],
		["Guess the Move", "Play like Morphy", func(): start_guess()],
	]
	for m in modes:
		grid.add_child(_btn(m[0] + "\n" + m[1], m[2], "dark", 32, 190))
	inner.add_child(grid)
	inner.add_child(_lbl("YOUR PROGRESS", 32, GOLD))
	var sp = _panel(CARD, 30, 26)
	sp.add_child(_lbl("Games: %d     Wins: %d     Losses: %d     Draws: %d\nPuzzles solved: %d     Lessons done: %d / %d" % [save.games, save.wins, save.losses, save.draws, save.solved, save.lessons.size(), ChessData.lessons().size()], 30, TXT))
	inner.add_child(sp)
	inner.add_child(_btn("Sound: " + ("ON" if save.sound else "OFF"), _toggle_sound, "dark", 32, 90))
	inner.add_child(_btn("Back to intro", show_splash, "ghost", 30, 80))
	inner.add_child(_lbl("", 40))

# ---------------------------------------------------------------- SETUP
func show_setup(m):
	setup_mode = m
	_clear()
	screen = "setup"
	var sc = ScrollContainer.new()
	_full(sc)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	ui.add_child(_gradient_rect(Color(0.03, 0.04, 0.09, 0.97), Color(0.02, 0.03, 0.07, 0.99)))
	ui.get_child(ui.get_child_count() - 1).set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.add_child(sc)
	var v = _vb(26)
	sc.add_child(_margin(v, 40))
	var titles = {"ai": "PLAY VS AI", "coach": "AI COACH GAME", "960": "CHESS960", "blind": "BLINDFOLD CHESS"}
	v.add_child(_btn("< Back", show_dashboard, "ghost", 30, 80))
	v.add_child(_lbl(titles[m], 56, GOLD))
	if m == "coach":
		v.add_child(_lbl("The coach grades every move you play, shows an evaluation bar and explains mistakes.", 28, MUTED))
	elif m == "blind":
		v.add_child(_lbl("Pieces are hidden. Tap squares to move from memory - use the Peek button if you must.", 28, MUTED))
	elif m == "960":
		v.add_child(_lbl("Random back-rank start. (Castling is disabled in this mode.)", 28, MUTED))
	v.add_child(_lbl("PLAY AS", 30, MUTED))
	v.add_child(_choice(["White", "Black", "Random"], setup_side, func(i): setup_side = i))
	v.add_child(_lbl("AI STRENGTH", 30, MUTED))
	var ll = _lbl("", 36, TXT)
	var upd = func():
		ll.text = "Level %d - %s  (about %d Elo)" % [level, LV_NAMES[level - 1], LV_ELO[level - 1]]
	var sl = HSlider.new()
	sl.min_value = 1
	sl.max_value = 9
	sl.step = 1
	sl.value = level
	sl.custom_minimum_size = Vector2(0, 70)
	sl.value_changed.connect(func(val):
		level = int(val)
		upd.call())
	upd.call()
	v.add_child(ll)
	v.add_child(sl)
	v.add_child(_lbl("AI PERSONALITY", 30, MUTED))
	v.add_child(_choice(STYLES, style, func(i): style = i))
	v.add_child(_lbl("CLOCK", 30, MUTED))
	var tl = []
	for t in TCS:
		tl.append(t[0])
	v.add_child(_choice(tl, tc_idx, func(i): tc_idx = i))
	v.add_child(_btn("START GAME", func(): start_game(setup_mode, {}), "gold", 46, 130))
	v.add_child(_lbl("", 40))

# ---------------------------------------------------------------- GAME
func _reset_play_state():
	sel = -1
	targets = []
	last = [-1, -1]
	hint_mv = [-1, -1]
	thinking = false
	over = false
	epoch += 1
	moves_hist = []
	san_hist = []
	fens = []
	result_text = ""
	board3d.clear_marks()

func _mode_title():
	var t = {"ai": "vs AI", "coach": "AI Coach", "960": "Chess960", "blind": "Blindfold", "local": "2 Players", "endgame": "Endgame Lab"}
	return t.get(mode, "Chess")

func start_game(m, opts):
	mode = m
	screen = "game"
	_reset_play_state()
	game = Chess.new()
	if m == "960":
		game.load_fen(Chess.fen960())
	elif opts.has("fen"):
		game.load_fen(opts.fen)
	else:
		game.reset()
	if m == "local":
		human = 1
	elif m == "endgame":
		human = game.turn
	else:
		human = 1 if setup_side == 0 else (-1 if setup_side == 1 else [1, -1].pick_random())
	coach_on = (m == "coach" or m == "endgame")
	blind = (m == "blind")
	hints_on = true
	play_level = 4 if m == "endgame" else level
	var tc = TCS[0] if m == "endgame" else TCS[tc_idx]
	clock = [float(tc[1]), float(tc[1])]
	inc = tc[2]
	board3d.showcase(false)
	board3d.set_flipped(human == -1)
	board3d.set_blind(blind)
	board3d.show_position(game)
	_clear()
	var show_clk = TCS[tc_idx][1] > 0 and m != "endgame"
	_frame(opts.get("title", _mode_title()), _pause, coach_on, show_clk)
	var bar = hud.bar
	bar.add_child(_btn("Undo", _undo, "dark", 28, 84))
	bar.add_child(_btn("Hint", _hint, "dark", 28, 84))
	bar.add_child(_btn("View", _cycle_view_msg, "dark", 28, 84))
	bar.add_child(_btn("Flip", func(): board3d.flip(), "dark", 28, 84))
	if m == "blind":
		bar.add_child(_btn("Peek", _peek, "dark", 28, 84))
	_refresh_hud()
	_marks()
	if _ai_turn():
		_request_ai()

var play_level = 5

func _frame(title, back_cb, show_eval = false, show_clocks = false):
	var top = PanelContainer.new()
	top.add_theme_stylebox_override("panel", _sb(PANEL, 36, Color(1, 1, 1, 0.1), 2, 22))
	_anchor_top(top, 20, 40)
	ui.add_child(top)
	var tv = _vb(10)
	top.add_child(tv)
	hud.topv = tv
	var row = _hb(14)
	tv.add_child(row)
	var bb = _btn("<", back_cb, "dark", 40, 80)
	bb.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	bb.custom_minimum_size = Vector2(100, 80)
	row.add_child(bb)
	hud.title = _lbl(title, 40, GOLD)
	row.add_child(hud.title)
	if show_clocks:
		hud.clock_top = _lbl("", 44, TXT, HORIZONTAL_ALIGNMENT_RIGHT)
		hud.clock_top.size_flags_horizontal = Control.SIZE_SHRINK_END
		row.add_child(hud.clock_top)
	hud.info = _lbl("", 32, TXT)
	tv.add_child(hud.info)
	if show_eval:
		var pb = ProgressBar.new()
		pb.min_value = 0
		pb.max_value = 100
		pb.value = 50
		pb.show_percentage = false
		pb.custom_minimum_size = Vector2(0, 22)
		pb.add_theme_stylebox_override("background", _sb(Color("#111111"), 11, Color(1, 1, 1, 0.25), 2, 0))
		pb.add_theme_stylebox_override("fill", _sb(Color("#f2f4fa"), 11, Color(0, 0, 0, 0), 0, 0))
		tv.add_child(pb)
		hud.eval = pb
	var bot = PanelContainer.new()
	bot.add_theme_stylebox_override("panel", _sb(PANEL, 36, Color(1, 1, 1, 0.1), 2, 22))
	_anchor_bottom(bot, 20, 40)
	ui.add_child(bot)
	var bv = _vb(10)
	bot.add_child(bv)
	if show_clocks:
		var cr = _hb(10)
		cr.add_child(_lbl("You", 32, MUTED))
		hud.clock_bot = _lbl("", 44, TXT, HORIZONTAL_ALIGNMENT_RIGHT)
		cr.add_child(hud.clock_bot)
		bv.add_child(cr)
	hud.msg = _lbl("", 31, MUTED)
	hud.msg.custom_minimum_size = Vector2(0, 80)
	bv.add_child(hud.msg)
	hud.moves = _lbl("", 25, MUTED)
	bv.add_child(hud.moves)
	hud.bar = _hb(12)
	bv.add_child(hud.bar)

func _fmt(t):
	var s = int(maxf(t, 0.0))
	return "%d:%02d" % [s / 60, s % 60]

func _refresh_clock():
	if not hud.has("clock_top"):
		return
	var me = 0 if human > 0 else 1
	if mode == "local":
		me = 0
	hud.clock_bot.text = _fmt(clock[me])
	hud.clock_top.text = _fmt(clock[1 - me])

func _refresh_hud():
	if not hud.has("info") or screen != "game":
		return
	var tt = "White to move" if game.turn > 0 else "Black to move"
	var s = tt
	if over:
		s = result_text
	elif thinking:
		s = "AI is thinking..."
	elif game.in_check(game.turn):
		s = tt + " - CHECK!"
	elif mode in ["ai", "coach", "960", "blind", "endgame"] and game.turn == human:
		s = "Your move"
	hud.info.text = s
	var ms = ""
	var n = san_hist.size()
	for i in range(maxi(0, n - 8), n):
		if i % 2 == 0:
			ms += str(i / 2 + 1) + ". "
		ms += san_hist[i] + " "
	hud.moves.text = ms
	_refresh_clock()

func _marks():
	var chk = -1
	if game.in_check(game.turn):
		chk = game.ksq[0 if game.turn > 0 else 1]
	board3d.show_marks(sel, targets, last, chk, hint_mv)

func _human_turn():
	if mode in ["local", "lesson", "puzzle", "guess"]:
		return true
	return game.turn == human

func _ai_turn():
	return mode in ["ai", "coach", "960", "blind", "endgame"] and not over and game.turn != human

func _own(sq):
	var p = game.b[sq]
	return p != 0 and (p > 0) == (game.turn > 0)

func _select(sq):
	sel = sq
	targets = []
	for m in game.legal_moves():
		if (m & 63) == sq:
			var to = (m >> 6) & 63
			var cap = game.b[to] != 0 or ((m >> 15) & 7) == 2
			var dup = false
			for t in targets:
				if t[0] == to:
					dup = true
			if not dup:
				targets.append([to, cap])
	_marks()

func _on_square(sq):
	if sq < 0 or over or thinking or screen == "analysis" or screen == "dash":
		return
	if not (screen == "game" or screen == "lesson" or screen == "puzzle" or screen == "guess"):
		return
	if hud.has("overlay") or not _human_turn():
		return
	if sel == -1:
		if _own(sq):
			_select(sq)
		return
	var cands = []
	for m in game.legal_moves():
		if (m & 63) == sel and ((m >> 6) & 63) == sq:
			cands.append(m)
	if cands.is_empty():
		if _own(sq) and sq != sel:
			_select(sq)
		else:
			sel = -1
			targets = []
			_marks()
		return
	if cands.size() > 1:
		_ask_promo(cands)
	else:
		_try_move(cands[0])

func _ask_promo(cands):
	var v = _overlay()
	v.add_child(_lbl("Promote to", 44, GOLD, HORIZONTAL_ALIGNMENT_CENTER))
	var names = {5: "Queen", 4: "Rook", 3: "Bishop", 2: "Knight"}
	for pt in [5, 4, 3, 2]:
		for m in cands:
			if ((m >> 12) & 7) == pt:
				var mm = m
				v.add_child(_btn(names[pt], _promo_pick.bind(mm), "dark", 38, 100))

func _try_move(m):
	if mode == "lesson":
		_lesson_move(m)
	elif mode == "puzzle":
		_puzzle_move(m)
	elif mode == "guess":
		_guess_move(m)
	else:
		_play_move(m, false)

func _play_move(m, by_ai = false):
	var cap = game.b[(m >> 6) & 63] != 0 or ((m >> 15) & 7) == 2
	var s = game.san(m)
	var fen_before = game.to_fen()
	fens.append(fen_before)
	var mover = game.turn
	game.make(m)
	game.keys.append(game.pos_key())
	moves_hist.append(m)
	san_hist.append(s)
	last = [m & 63, (m >> 6) & 63]
	sel = -1
	targets = []
	hint_mv = [-1, -1]
	board3d.animate_move(m)
	_play("cap" if cap else "move")
	if TCS[tc_idx][1] > 0 and mode != "endgame":
		clock[0 if mover > 0 else 1] += inc
	if mode == "local" and board3d.flipped != (game.turn < 0):
		board3d.flip()
	var st = game.status()
	if st == "" and game.in_check(game.turn):
		_play("check")
		board3d.pulse()
	_marks()
	if coach_on and mover == human:
		var c = Chess.new()
		c.load_fen(fen_before)
		hud.msg.text = "Coach is analysing..."
		hud.msg.add_theme_color_override("font_color", MUTED)
		_start_job("coach", {"c": c, "m": m}, epoch)
	if coach_on:
		_start_job("eval", {"c": game.copy()}, epoch)
	_refresh_hud()
	if st != "":
		_end_game(st)
	elif _ai_turn():
		_request_ai()

func _request_ai():
	thinking = true
	_refresh_hud()
	var my = epoch
	await get_tree().create_timer(0.4).timeout
	if my != epoch or over:
		return
	_start_job("ai", {"c": game.copy(), "lvl": play_level, "style": style}, my)

func _hint():
	if thinking or over or not _human_turn() or mode == "local":
		return
	hud.msg.text = "Thinking of a hint..."
	hud.msg.add_theme_color_override("font_color", MUTED)
	_start_job("hint", {"c": game.copy()}, epoch)

func _undo():
	if thinking or over or moves_hist.is_empty():
		return
	epoch += 1
	var n = 1
	if mode != "local" and moves_hist.size() >= 2 and game.turn == human:
		n = 2
	for i in range(n):
		game.unmake()
		game.keys.pop_back()
		moves_hist.pop_back()
		san_hist.pop_back()
		fens.pop_back()
	last = [-1, -1]
	sel = -1
	targets = []
	hint_mv = [-1, -1]
	board3d.show_position(game)
	board3d.set_blind(blind)
	if mode == "local" and board3d.flipped != (game.turn < 0):
		board3d.flip()
	_marks()
	_refresh_hud()

func _end_game(st):
	if over:
		return
	over = true
	thinking = false
	var winner = 0
	if st == "checkmate" or st == "timeout":
		winner = -game.turn
	elif st == "resign":
		winner = -human
	var side = "White" if winner > 0 else "Black"
	var txt = ""
	match st:
		"checkmate":
			txt = "Checkmate! " + side + " wins"
		"timeout":
			txt = side + " wins on time"
		"resign":
			txt = side + " wins by resignation"
		"stalemate":
			txt = "Stalemate - draw"
		"fifty":
			txt = "Draw - 50 move rule"
		"insufficient":
			txt = "Draw - insufficient material"
		"repetition":
			txt = "Draw - threefold repetition"
		_:
			txt = "Draw agreed"
	var delta = 0
	if mode in ["ai", "coach", "960", "blind"]:
		var score = 0.5
		if winner != 0:
			score = 1.0 if winner == human else 0.0
		var expct = 1.0 / (1.0 + pow(10.0, float(LV_ELO[play_level - 1] - save.rating) / 400.0))
		delta = int(round(32.0 * (score - expct)))
		save.rating = maxi(100, save.rating + delta)
		save.games += 1
		if score == 1.0:
			save.wins += 1
		elif score == 0.0:
			save.losses += 1
		else:
			save.draws += 1
		_add_xp(30 if score == 1.0 else 12)
		txt += "   (rating %+d)" % delta
	elif mode == "endgame" and winner == human:
		_add_xp(25)
	result_text = txt
	_refresh_hud()
	if st == "checkmate":
		board3d.mate_cinematic(game.ksq[0 if game.turn > 0 else 1])
	_play("win" if (winner == human or mode == "local") else "bad")
	var my = epoch
	await get_tree().create_timer(1.8 if st == "checkmate" else 0.6).timeout
	if my != epoch or screen != "game":
		return
	var v = _overlay()
	v.add_child(_lbl(txt, 44, GOLD, HORIZONTAL_ALIGNMENT_CENTER))
	if moves_hist.size() > 1:
		v.add_child(_btn("AI Game Review", _analyze, "gold", 36, 100))
	v.add_child(_btn("Rematch", _rematch, "dark", 36, 100))
	v.add_child(_btn("Dashboard", show_dashboard, "dark", 36, 100))

func _overlay():
	_close_overlay()
	var dim = ColorRect.new()
	dim.color = Color(0, 0, 0, 0.68)
	_full(dim)
	ui.add_child(dim)
	var cc = CenterContainer.new()
	_full(cc)
	dim.add_child(cc)
	var p = _panel(PANEL, 40, 36)
	p.custom_minimum_size = Vector2(840, 0)
	cc.add_child(p)
	var v = _vb(18)
	p.add_child(v)
	hud.overlay = dim
	return v

func _close_overlay():
	if hud.has("overlay"):
		if is_instance_valid(hud.overlay):
			hud.overlay.queue_free()
		hud.erase("overlay")

func _pause():
	if hud.has("overlay"):
		_close_overlay()
		return
	var v = _overlay()
	v.add_child(_lbl("PAUSED", 52, GOLD, HORIZONTAL_ALIGNMENT_CENTER))
	v.add_child(_btn("Resume", _close_overlay, "gold", 36, 100))
	if not over:
		v.add_child(_btn("Restart", _rematch, "dark", 36, 100))
		if mode == "local":
			v.add_child(_btn("Agree draw", _agree_draw, "dark", 36, 100))
		else:
			v.add_child(_btn("Resign", _resign, "red", 36, 100))
	v.add_child(_btn("Exit to Dashboard", show_dashboard, "dark", 36, 100))

func _analyze():
	_close_overlay()
	analysis = {"fens": fens + [game.to_fen()], "moves": moves_hist.duplicate(), "sans": san_hist.duplicate()}
	var v = _overlay()
	v.add_child(_lbl("Analysing your game...", 40, GOLD, HORIZONTAL_ALIGNMENT_CENTER))
	v.add_child(_lbl("The engine is grading every move.", 28, MUTED, HORIZONTAL_ALIGNMENT_CENTER))
	_start_job("analyze", {"fens": analysis.fens, "moves": analysis.moves, "depth": 2 if analysis.moves.size() <= 50 else 1}, -1)

# ---------------------------------------------------------------- REVIEW
const CLS = ["Best", "Good", "Inaccuracy", "Mistake", "Blunder"]
const CLS_COL = [Color("#46d18c"), Color("#9be7bf"), Color("#ffb347"), Color("#ff8a47"), Color("#ff5d6c")]

func _cls(loss):
	if loss <= 12:
		return 0
	if loss <= 40:
		return 1
	if loss <= 100:
		return 2
	if loss <= 250:
		return 3
	return 4

func _show_analysis(res):
	analysis["losses"] = res.losses
	analysis["bests"] = res.bests
	analysis["evals"] = res.evals
	_clear()
	screen = "analysis"
	mode = "analysis"
	board3d.showcase(false)
	board3d.set_blind(false)
	var n = analysis.moves.size()
	var tot = [0.0, 0.0]
	var cnt = [0, 0]
	var cc = [[0, 0, 0, 0, 0], [0, 0, 0, 0, 0]]
	for i in range(n):
		var side = 0 if analysis.fens[i].contains(" w ") else 1
		tot[side] += minf(float(res.losses[i]), 500.0)
		cnt[side] += 1
		cc[side][_cls(res.losses[i])] += 1
	var acc = []
	for s in range(2):
		acc.append(100.0 * exp(-(tot[s] / maxf(float(cnt[s]), 1.0)) / 180.0))
	_frame("AI Game Review", show_dashboard)
	hud.info.text = "White accuracy %d%%   |   Black accuracy %d%%" % [int(acc[0]), int(acc[1])]
	var g = GraphView.new()
	g.custom_minimum_size = Vector2(0, 170)
	g.data = res.evals
	hud.topv.add_child(g)
	hud.graph = g
	var names = ["White", "Black"]
	var ms = ""
	for s in range(2):
		ms += "%s: %d best, %d good, %d inacc., %d mistakes, %d blunders\n" % [names[s], cc[s][0], cc[s][1], cc[s][2], cc[s][3], cc[s][4]]
	hud.moves.text = ms
	hud.bar.add_child(_btn("|<", func(): _an_show(0), "dark", 30, 84))
	hud.bar.add_child(_btn("<", func(): _an_show(an_idx - 1), "dark", 30, 84))
	hud.bar.add_child(_btn(">", func(): _an_show(an_idx + 1), "dark", 30, 84))
	hud.bar.add_child(_btn(">|", func(): _an_show(analysis.moves.size()), "dark", 30, 84))
	_an_show(0)

func _an_show(i):
	var n = analysis.moves.size()
	an_idx = clampi(i, 0, n)
	var c = Chess.new()
	c.load_fen(analysis.fens[an_idx])
	board3d.show_position(c)
	var lm = [-1, -1]
	if an_idx > 0:
		var m = analysis.moves[an_idx - 1]
		lm = [m & 63, (m >> 6) & 63]
	board3d.show_marks(-1, [], lm, -1, [-1, -1])
	hud.graph.cur = an_idx
	hud.graph.queue_redraw()
	if an_idx == 0:
		hud.msg.text = "Start position - use > to step through the game."
		hud.msg.add_theme_color_override("font_color", MUTED)
		return
	var k = an_idx - 1
	var f = analysis.fens[k]
	var white = f.contains(" w ")
	var num = int(f.split(" ")[5])
	var loss = analysis.losses[k]
	var cl = _cls(loss)
	var t = "%d%s %s - %s" % [num, "." if white else "...", analysis.sans[k], CLS[cl]]
	if loss > 40:
		t += "   (better: " + analysis.bests[k] + ")"
	hud.msg.text = t
	hud.msg.add_theme_color_override("font_color", CLS_COL[cl])

# ---------------------------------------------------------------- ACADEMY
func _page():
	ui.add_child(_gradient_rect(Color(0.03, 0.04, 0.09, 0.97), Color(0.02, 0.03, 0.07, 0.99)))
	_full(ui.get_child(ui.get_child_count() - 1))
	var sc = ScrollContainer.new()
	_full(sc)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	ui.add_child(sc)
	var v = _vb(22)
	sc.add_child(_margin(v, 40))
	return v

func show_academy():
	_clear()
	screen = "academy"
	mode = "menu"
	var v = _page()
	v.add_child(_btn("< Back", show_dashboard, "ghost", 30, 80))
	v.add_child(_lbl("LEARNING ACADEMY", 56, GOLD))
	v.add_child(_lbl("Learn by playing on the real 3D board - short steps, instant feedback, no long reading.", 29, MUTED))
	v.add_child(_lbl("MODERN LEARNING METHODS", 32, GOLD))
	var methods = [
		["Learn by doing", "Every lesson is a tiny challenge you solve on the board, then the next one unlocks."],
		["Spaced repetition", "Puzzles you miss come back sooner; the ones you master return later."],
		["Guess the move", "Predict a master's moves in a famous game and see the ideas behind them."],
		["Live AI coach", "Play a Coach Game: every move is graded and mistakes are explained."],
		["Game review", "After each game the AI grades every move and shows an evaluation graph."],
		["Endgame lab", "Drill key endings against the AI with hints turned on."],
		["Visualisation", "Blindfold mode trains your mind to see the board without pieces."],
	]
	for m in methods:
		var p = _panel(CARD, 28, 22)
		var pv = _vb(4)
		pv.add_child(_lbl(m[0], 32, GOLD))
		pv.add_child(_lbl(m[1], 27, TXT))
		p.add_child(pv)
		v.add_child(p)
	var row = _hb(14)
	row.add_child(_btn("Puzzles", start_puzzle, "gold", 30, 90))
	row.add_child(_btn("Guess the Move", start_guess, "dark", 30, 90))
	v.add_child(row)
	v.add_child(_btn("Play a Coach Game", func(): show_setup("coach"), "dark", 30, 90))
	var cat = ""
	var ls = ChessData.lessons()
	for i in range(ls.size()):
		if ls[i].cat != cat:
			cat = ls[i].cat
			v.add_child(_lbl(cat.to_upper(), 32, GOLD))
		var done = save.lessons.has(ls[i].title)
		v.add_child(_btn(("[done]  " if done else "") + ls[i].title, start_lesson.bind(i), "sel" if done else "dark", 32, 90))
	v.add_child(_lbl("", 40))

func start_lesson(i):
	var L = ChessData.lessons()[i]
	lesson_i = i
	if L.get("practice", false):
		setup_side = 0
		start_game("endgame", {"fen": L.fen, "title": L.title})
		return
	mode = "lesson"
	screen = "lesson"
	_reset_play_state()
	game = Chess.new()
	game.load_fen(L.fen)
	coach_on = false
	blind = false
	board3d.showcase(false)
	board3d.set_flipped(false)
	board3d.set_blind(false)
	board3d.show_position(game)
	_clear()
	_frame(L.title, show_academy)
	hud.info.text = L.text
	hud.msg.text = "Tap a piece, then tap a green dot."
	hud.bar.add_child(_btn("Hint", _lesson_hint, "dark", 28, 84))
	hud.bar.add_child(_btn("Retry", func(): start_lesson(lesson_i), "dark", 28, 84))
	hud.bar.add_child(_btn("Next", _lesson_next, "gold", 28, 84))
	_marks()

func _lesson_next():
	var n = ChessData.lessons().size()
	if lesson_i + 1 < n:
		start_lesson(lesson_i + 1)
	else:
		show_academy()

func _lesson_hint():
	var L = ChessData.lessons()[lesson_i]
	var g = L.get("goal", "info")
	if typeof(g) == TYPE_ARRAY:
		g = g[0]
	if g == "any" or g == "info":
		hud.msg.text = "Any legal move works - just try one!"
		return
	hint_mv = [(g.unicode_at(0) - 97) + (int(g[1]) - 1) * 8, (g.unicode_at(2) - 97) + (int(g[3]) - 1) * 8]
	_marks()
	hud.msg.text = "Follow the blue squares."

func _lesson_move(m):
	var L = ChessData.lessons()[lesson_i]
	var goal = L.get("goal", "info")
	var goals = []
	var ok = false
	if typeof(goal) == TYPE_ARRAY:
		goals = goal
	elif goal == "any":
		ok = true
	else:
		goals = [goal]
	var u = game.uci(m)
	for g in goals:
		if u.begins_with(g):
			ok = true
	if not ok:
		hud.msg.text = "Not quite - think again and retry!"
		hud.msg.add_theme_color_override("font_color", RED)
		_play("bad")
		sel = -1
		targets = []
		_marks()
		return
	var cap = game.b[(m >> 6) & 63] != 0 or ((m >> 15) & 7) == 2
	game.make(m)
	board3d.animate_move(m)
	_play("cap" if cap else "move")
	last = [m & 63, (m >> 6) & 63]
	sel = -1
	targets = []
	hint_mv = [-1, -1]
	_marks()
	over = true
	hud.msg.text = "Correct! Well done. Tap Next."
	hud.msg.add_theme_color_override("font_color", GREEN)
	if not save.lessons.has(L.title):
		save.lessons.append(L.title)
		_add_xp(15)

# ---------------------------------------------------------------- PUZZLES
func _pick_puzzle():
	var best = []
	var bb = 99
	var ps = ChessData.puzzles()
	for p in ps:
		if puzzle != null and p.id == puzzle.id and ps.size() > 1:
			continue
		var bx = save.pbox.get(p.id, 0)
		if bx < bb:
			bb = bx
			best = [p]
		elif bx == bb:
			best.append(p)
	return best.pick_random()

func start_puzzle():
	puzzle = _pick_puzzle()
	puzzle_step = 0
	puzzle_hinted = false
	puzzle_failed = false
	mode = "puzzle"
	screen = "puzzle"
	_reset_play_state()
	game = Chess.new()
	game.load_fen(puzzle.fen)
	human = game.turn
	coach_on = false
	blind = false
	board3d.showcase(false)
	board3d.set_flipped(human == -1)
	board3d.set_blind(false)
	board3d.show_position(game)
	_clear()
	_frame("Puzzle: " + puzzle.title, show_dashboard)
	hud.info.text = puzzle.text + "   (mastery %d/4)" % save.pbox.get(puzzle.id, 0)
	hud.msg.text = "Find the best move."
	hud.bar.add_child(_btn("Hint", _puzzle_hint, "dark", 28, 84))
	hud.bar.add_child(_btn("Skip", start_puzzle, "dark", 28, 84))
	_marks()

func _puzzle_hint():
	if over or thinking:
		return
	puzzle_hinted = true
	var u = puzzle.sol[puzzle_step]
	hint_mv = [(u.unicode_at(0) - 97) + (int(u[1]) - 1) * 8, (u.unicode_at(2) - 97) + (int(u[3]) - 1) * 8]
	_marks()
	hud.msg.text = "Hint: move the piece on the blue square."

func _puzzle_apply(m):
	var cap = game.b[(m >> 6) & 63] != 0 or ((m >> 15) & 7) == 2
	game.make(m)
	board3d.animate_move(m)
	_play("cap" if cap else "move")
	last = [m & 63, (m >> 6) & 63]
	sel = -1
	targets = []
	hint_mv = [-1, -1]
	_marks()

func _puzzle_move(m):
	var u = game.uci(m)
	var ok = (u == puzzle.sol[puzzle_step])
	var is_last = puzzle_step >= puzzle.sol.size() - 1
	if not ok and puzzle.mate and is_last:
		game.make(m)
		ok = game.legal_moves().is_empty() and game.in_check(game.turn)
		game.unmake()
	if not ok:
		hud.msg.text = "Not the best move - try again!"
		hud.msg.add_theme_color_override("font_color", RED)
		_play("bad")
		sel = -1
		targets = []
		_marks()
		if not puzzle_failed:
			puzzle_failed = true
			save.pbox[puzzle.id] = 0
			_save()
		return
	_puzzle_apply(m)
	puzzle_step += 1
	if puzzle_step >= puzzle.sol.size():
		_puzzle_solved()
		return
	thinking = true
	var my = epoch
	await get_tree().create_timer(0.8).timeout
	if my != epoch:
		return
	var rm = game.find_uci(puzzle.sol[puzzle_step])
	if rm >= 0:
		_puzzle_apply(rm)
	puzzle_step += 1
	thinking = false
	hud.msg.text = "Good! Keep going."
	hud.msg.add_theme_color_override("font_color", GREEN)
	if puzzle_step >= puzzle.sol.size():
		_puzzle_solved()

func _puzzle_solved():
	over = true
	_play("win")
	hud.msg.text = "Solved!  +20 XP"
	hud.msg.add_theme_color_override("font_color", GREEN)
	if not puzzle_failed and not puzzle_hinted:
		save.pbox[puzzle.id] = mini(save.pbox.get(puzzle.id, 0) + 1, 4)
	save.solved += 1
	_add_xp(20)
	hud.bar.add_child(_btn("Next puzzle", start_puzzle, "gold", 30, 84))

# ---------------------------------------------------------------- GUESS THE MOVE
func start_guess():
	mode = "guess"
	screen = "guess"
	_reset_play_state()
	game = Chess.new()
	game.reset()
	human = 1
	coach_on = false
	blind = false
	guess_i = 0
	guess_score = 0
	guess_wrong = 0
	board3d.showcase(false)
	board3d.set_flipped(false)
	board3d.set_blind(false)
	board3d.show_position(game)
	_clear()
	_frame("Guess the Move", show_dashboard)
	hud.info.text = "Morphy vs Duke of Brunswick, Paris 1858. You are White - guess Morphy's move!"
	hud.bar.add_child(_btn("Show move", _guess_show, "dark", 28, 84))
	hud.bar.add_child(_btn("Restart", start_guess, "dark", 28, 84))
	_guess_note()
	_marks()

func _guess_note():
	var n = ChessData.opera_notes().get(guess_i, "")
	hud.msg.text = "Your move. " + ("Theme: " + n if n != "" else "")
	hud.msg.add_theme_color_override("font_color", MUTED)

func _guess_apply(m):
	var cap = game.b[(m >> 6) & 63] != 0 or ((m >> 15) & 7) == 2
	game.make(m)
	board3d.animate_move(m)
	_play("cap" if cap else "move")
	last = [m & 63, (m >> 6) & 63]
	sel = -1
	targets = []
	hint_mv = [-1, -1]
	guess_i += 1
	_marks()

func _guess_move(m):
	var seq = ChessData.opera()
	if game.uci(m) != seq[guess_i]:
		guess_wrong += 1
		hud.msg.text = "Not Morphy's choice - try again, or tap Show move."
		hud.msg.add_theme_color_override("font_color", RED)
		_play("bad")
		sel = -1
		targets = []
		_marks()
		return
	guess_score += 1
	_guess_apply(m)
	_guess_after()

func _guess_show():
	if over or thinking:
		return
	var m = game.find_uci(ChessData.opera()[guess_i])
	if m >= 0:
		guess_wrong += 1
		_guess_apply(m)
		_guess_after()

func _guess_after():
	var seq = ChessData.opera()
	if guess_i >= seq.size():
		_guess_done()
		return
	thinking = true
	var my = epoch
	await get_tree().create_timer(0.9).timeout
	if my != epoch:
		return
	var rm = game.find_uci(seq[guess_i])
	if rm >= 0:
		_guess_apply(rm)
	thinking = false
	if guess_i >= seq.size():
		_guess_done()
	else:
		_guess_note()

func _guess_done():
	over = true
	_play("win")
	hud.msg.text = "Checkmate! Game complete. Correct guesses: %d, misses: %d.  +40 XP" % [guess_score, guess_wrong]
	hud.msg.add_theme_color_override("font_color", GREEN)
	_add_xp(40)
	board3d.mate_cinematic(game.ksq[1])

# ---------------------------------------------------------------- navigation helpers
func _back():
	if screen == "game":
		_pause()
		return
	if hud.has("overlay"):
		_close_overlay()
		return
	match screen:
		"splash":
			get_tree().quit()
		"dash":
			show_splash()
		"lesson":
			show_academy()
		_:
			show_dashboard()

func _cycle_view_msg():
	hud.msg.text = "Camera: " + board3d.cycle_view()
	hud.msg.add_theme_color_override("font_color", MUTED)

func _peek():
	board3d.set_blind(false)
	await get_tree().create_timer(1.5).timeout
	board3d.set_blind(true)

func _toggle_sound():
	save.sound = not save.sound
	_save()
	show_dashboard()

func _agree_draw():
	_close_overlay()
	_end_game("agreed")

func _resign():
	_close_overlay()
	_end_game("resign")

func _rematch():
	var o = {}
	if mode == "endgame" and fens.size() > 0:
		o = {"fen": fens[0]}
	start_game(mode, o)

func _promo_pick(m):
	_close_overlay()
	_try_move(m)
