class_name Chess
extends RefCounted
# Full legal chess rules. Piece codes: 1 P, 2 N, 3 B, 4 R, 5 Q, 6 K (white +, black -)
# Move int: from | to<<6 | promo<<12 | flag<<15  (flag: 1 double push, 2 en passant, 3 O-O, 4 O-O-O)

const KN = [[1, 2], [2, 1], [-1, 2], [-2, 1], [1, -2], [2, -1], [-1, -2], [-2, -1]]
const KG = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]]
const DG = [[1, 1], [1, -1], [-1, 1], [-1, -1]]
const OR = [[1, 0], [-1, 0], [0, 1], [0, -1]]
const RIGHTS = {0: 2, 7: 1, 4: 3, 56: 8, 63: 4, 60: 12}
const START = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

var b = []
var turn = 1
var castle = 15
var ep = -1
var half = 0
var full = 1
var stack = []
var keys = []
var ksq = [-1, -1]

func _init():
	b.resize(64)
	b.fill(0)

func reset():
	load_fen(START)

static func sq_name(sq):
	return "abcdefgh"[sq & 7] + str((sq >> 3) + 1)

static func fen960():
	var rng = RandomNumberGenerator.new()
	rng.randomize()
	var row = ["", "", "", "", "", "", "", ""]
	var slots = [0, 1, 2, 3, 4, 5, 6, 7]
	var ev = [0, 2, 4, 6]
	var od = [1, 3, 5, 7]
	var b1 = ev[rng.randi() % 4]
	row[b1] = "b"
	slots.erase(b1)
	var b2 = od[rng.randi() % 4]
	row[b2] = "b"
	slots.erase(b2)
	for ch in ["q", "n", "n"]:
		var s = slots[rng.randi() % slots.size()]
		row[s] = ch
		slots.erase(s)
	slots.sort()
	row[slots[0]] = "r"
	row[slots[1]] = "k"
	row[slots[2]] = "r"
	var s1 = "".join(row)
	return s1 + "/pppppppp/8/8/8/8/PPPPPPPP/" + s1.to_upper() + " w - - 0 1"

func load_fen(fen):
	var parts = fen.split(" ")
	b.fill(0)
	ksq = [-1, -1]
	var rows = parts[0].split("/")
	for i in range(8):
		var r = 7 - i
		var f = 0
		for ch in rows[i]:
			if ch.is_valid_int():
				f += int(ch)
			else:
				var t = "pnbrqk".find(ch.to_lower()) + 1
				var white = (ch == ch.to_upper())
				b[r * 8 + f] = t if white else -t
				if t == 6:
					ksq[0 if white else 1] = r * 8 + f
				f += 1
	turn = 1 if (parts.size() < 2 or parts[1] == "w") else -1
	castle = 0
	if parts.size() > 2:
		if "K" in parts[2]: castle |= 1
		if "Q" in parts[2]: castle |= 2
		if "k" in parts[2]: castle |= 4
		if "q" in parts[2]: castle |= 8
	ep = -1
	if parts.size() > 3 and parts[3] != "-":
		ep = (parts[3].unicode_at(0) - 97) + (int(parts[3][1]) - 1) * 8
	half = int(parts[4]) if parts.size() > 4 else 0
	full = int(parts[5]) if parts.size() > 5 else 1
	stack.clear()
	keys = [pos_key()]

func to_fen():
	var s = ""
	for r in range(7, -1, -1):
		var e = 0
		for f in range(8):
			var p = b[r * 8 + f]
			if p == 0:
				e += 1
			else:
				if e > 0:
					s += str(e)
					e = 0
				var ch = "pnbrqk"[absi(p) - 1]
				s += ch.to_upper() if p > 0 else ch
		if e > 0:
			s += str(e)
		if r > 0:
			s += "/"
	s += " w " if turn > 0 else " b "
	var cs = ""
	if castle & 1: cs += "K"
	if castle & 2: cs += "Q"
	if castle & 4: cs += "k"
	if castle & 8: cs += "q"
	s += cs if cs != "" else "-"
	s += " " + (sq_name(ep) if ep >= 0 else "-")
	s += " " + str(half) + " " + str(full)
	return s

func pos_key():
	return [b.hash(), turn, castle, ep]

func copy():
	var c = Chess.new()
	c.b = b.duplicate()
	c.turn = turn
	c.castle = castle
	c.ep = ep
	c.half = half
	c.full = full
	c.ksq = ksq.duplicate()
	return c

func attacked(sq, by):
	var f = sq & 7
	var r = sq >> 3
	var pr = r - by
	if pr >= 0 and pr < 8:
		for df in [-1, 1]:
			var pf = f + df
			if pf >= 0 and pf < 8 and b[pr * 8 + pf] == by:
				return true
	for o in KN:
		var nf = f + o[0]
		var nr = r + o[1]
		if nf >= 0 and nf < 8 and nr >= 0 and nr < 8 and b[nr * 8 + nf] == 2 * by:
			return true
	for o in KG:
		var nf = f + o[0]
		var nr = r + o[1]
		if nf >= 0 and nf < 8 and nr >= 0 and nr < 8 and b[nr * 8 + nf] == 6 * by:
			return true
	for o in OR:
		var nf = f + o[0]
		var nr = r + o[1]
		while nf >= 0 and nf < 8 and nr >= 0 and nr < 8:
			var v = b[nr * 8 + nf]
			if v != 0:
				if v == 4 * by or v == 5 * by:
					return true
				break
			nf += o[0]
			nr += o[1]
	for o in DG:
		var nf = f + o[0]
		var nr = r + o[1]
		while nf >= 0 and nf < 8 and nr >= 0 and nr < 8:
			var v = b[nr * 8 + nf]
			if v != 0:
				if v == 3 * by or v == 5 * by:
					return true
				break
			nf += o[0]
			nr += o[1]
	return false

func in_check(color):
	var k = ksq[0 if color > 0 else 1]
	if k < 0:
		return false
	return attacked(k, -color)

func _pp(out, sq, to, nr):
	if nr == 7 or nr == 0:
		for pt in [5, 4, 3, 2]:
			out.append(sq | (to << 6) | (pt << 12))
	else:
		out.append(sq | (to << 6))

func pseudo():
	var out = []
	var me = turn
	for sq in range(64):
		var p = b[sq]
		if p == 0 or (p > 0) != (me > 0):
			continue
		var t = absi(p)
		var f = sq & 7
		var r = sq >> 3
		if t == 1:
			var pr = r + me
			if pr >= 0 and pr <= 7:
				var to = pr * 8 + f
				if b[to] == 0:
					_pp(out, sq, to, pr)
					var start = 1 if me > 0 else 6
					if r == start and b[to + me * 8] == 0:
						out.append(sq | ((to + me * 8) << 6) | (1 << 15))
				for df in [-1, 1]:
					var pf = f + df
					if pf < 0 or pf > 7:
						continue
					var t2 = pr * 8 + pf
					if b[t2] != 0 and (b[t2] > 0) != (me > 0):
						_pp(out, sq, t2, pr)
					elif t2 == ep and b[t2] == 0:
						out.append(sq | (t2 << 6) | (2 << 15))
		elif t == 2 or t == 6:
			var offs = KN if t == 2 else KG
			for o in offs:
				var nf = f + o[0]
				var nr = r + o[1]
				if nf < 0 or nf > 7 or nr < 0 or nr > 7:
					continue
				var to = nr * 8 + nf
				if b[to] == 0 or (b[to] > 0) != (me > 0):
					out.append(sq | (to << 6))
			if t == 6:
				_castles(out, sq)
		else:
			var dirs = DG + OR
			if t == 3:
				dirs = DG
			elif t == 4:
				dirs = OR
			for o in dirs:
				var nf = f + o[0]
				var nr = r + o[1]
				while nf >= 0 and nf < 8 and nr >= 0 and nr < 8:
					var to = nr * 8 + nf
					if b[to] == 0:
						out.append(sq | (to << 6))
					else:
						if (b[to] > 0) != (me > 0):
							out.append(sq | (to << 6))
						break
					nf += o[0]
					nr += o[1]
	return out

func _castles(out, sq):
	if turn > 0 and sq == 4:
		if (castle & 1) != 0 and b[5] == 0 and b[6] == 0 and b[7] == 4 and not attacked(4, -1) and not attacked(5, -1) and not attacked(6, -1):
			out.append(4 | (6 << 6) | (3 << 15))
		if (castle & 2) != 0 and b[1] == 0 and b[2] == 0 and b[3] == 0 and b[0] == 4 and not attacked(4, -1) and not attacked(3, -1) and not attacked(2, -1):
			out.append(4 | (2 << 6) | (4 << 15))
	elif turn < 0 and sq == 60:
		if (castle & 4) != 0 and b[61] == 0 and b[62] == 0 and b[63] == -4 and not attacked(60, 1) and not attacked(61, 1) and not attacked(62, 1):
			out.append(60 | (62 << 6) | (3 << 15))
		if (castle & 8) != 0 and b[57] == 0 and b[58] == 0 and b[59] == 0 and b[56] == -4 and not attacked(60, 1) and not attacked(59, 1) and not attacked(58, 1):
			out.append(60 | (58 << 6) | (4 << 15))

func make(m):
	var from = m & 63
	var to = (m >> 6) & 63
	var promo = (m >> 12) & 7
	var flag = (m >> 15) & 7
	var p = b[from]
	var cap = b[to]
	if flag == 2:
		cap = b[to - 8 * turn]
	stack.append([m, cap, castle, ep, half, p])
	b[to] = p
	b[from] = 0
	if flag == 2:
		b[to - 8 * turn] = 0
	if promo != 0:
		b[to] = promo * turn
	if flag == 3:
		b[to - 1] = b[to + 1]
		b[to + 1] = 0
	elif flag == 4:
		b[to + 1] = b[to - 2]
		b[to - 2] = 0
	if absi(p) == 6:
		ksq[0 if p > 0 else 1] = to
	castle &= ~(RIGHTS.get(from, 0))
	castle &= ~(RIGHTS.get(to, 0))
	ep = from + 8 * turn if flag == 1 else -1
	half = 0 if (absi(p) == 1 or cap != 0) else half + 1
	if turn < 0:
		full += 1
	turn = -turn

func unmake():
	var rec = stack.pop_back()
	var m = rec[0]
	var from = m & 63
	var to = (m >> 6) & 63
	var flag = (m >> 15) & 7
	var p = rec[5]
	turn = -turn
	if turn < 0:
		full -= 1
	b[from] = p
	if flag == 2:
		b[to] = 0
		b[to - 8 * turn] = rec[1]
	else:
		b[to] = rec[1]
	if flag == 3:
		b[to + 1] = b[to - 1]
		b[to - 1] = 0
	elif flag == 4:
		b[to - 2] = b[to + 1]
		b[to + 1] = 0
	castle = rec[2]
	ep = rec[3]
	half = rec[4]
	if absi(p) == 6:
		ksq[0 if p > 0 else 1] = from

func legal_moves():
	var res = []
	for m in pseudo():
		var mover = turn
		make(m)
		var k = ksq[0 if mover > 0 else 1]
		if k < 0 or not attacked(k, -mover):
			res.append(m)
		unmake()
	return res

func insufficient():
	var minors = 0
	for v in b:
		var t = absi(v)
		if t == 1 or t == 4 or t == 5:
			return false
		if t == 2 or t == 3:
			minors += 1
	return minors <= 1

func status():
	var mv = legal_moves()
	if mv.is_empty():
		return "checkmate" if in_check(turn) else "stalemate"
	if half >= 100:
		return "fifty"
	if insufficient():
		return "insufficient"
	if keys.size() > 0 and keys.count(keys[keys.size() - 1]) >= 3:
		return "repetition"
	return ""

func uci(m):
	var s = sq_name(m & 63) + sq_name((m >> 6) & 63)
	var promo = (m >> 12) & 7
	if promo != 0:
		s += "nbrq"[promo - 2]
	return s

func find_uci(s):
	for m in legal_moves():
		if uci(m) == s:
			return m
	return -1

func san(m):
	var from = m & 63
	var to = (m >> 6) & 63
	var flag = (m >> 15) & 7
	var promo = (m >> 12) & 7
	var p = absi(b[from])
	var s = ""
	if flag == 3:
		s = "O-O"
	elif flag == 4:
		s = "O-O-O"
	else:
		var cap = b[to] != 0 or flag == 2
		if p == 1:
			if cap:
				s += "abcdefgh"[from & 7] + "x"
		else:
			s += "PNBRQK"[p - 1]
			var same = []
			for mm in legal_moves():
				if ((mm >> 6) & 63) == to and (mm & 63) != from and absi(b[mm & 63]) == p:
					same.append(mm)
			if same.size() > 0:
				var sf = false
				var sr = false
				for mm in same:
					if ((mm & 63) & 7) == (from & 7):
						sf = true
					if ((mm & 63) >> 3) == (from >> 3):
						sr = true
				if not sf:
					s += "abcdefgh"[from & 7]
				elif not sr:
					s += str((from >> 3) + 1)
				else:
					s += sq_name(from)
			if cap:
				s += "x"
		s += sq_name(to)
		if promo != 0:
			s += "=" + "PNBRQK"[promo - 1]
	make(m)
	if in_check(turn):
		s += "#" if legal_moves().is_empty() else "+"
	unmake()
	return s
