class_name ChessAI
extends RefCounted
# Built-in alpha-beta engine (iterative deepening + quiescence). 9 strength levels, 5 play styles.

const VAL = [0, 100, 320, 330, 500, 900, 0]
const DEPTH = [1, 1, 2, 2, 3, 4, 5, 6, 8]
const TIME = [300, 500, 800, 1200, 1800, 2500, 3500, 5000, 7000]
const BLUN = [0.55, 0.30, 0.15, 0.08, 0.03, 0.0, 0.0, 0.0, 0.0]
const NOISE = [150, 100, 60, 40, 15, 0, 0, 0, 0]
const QLIM = [0, 0, 2, 3, 4, 6, 8, 8, 10]

var rng = RandomNumberGenerator.new()
var stop = false
var nodes = 0
var deadline = 0
var qlimit = 4
var style = 0

func _init():
	rng.randomize()

func evaluate(c):
	var bd = c.b
	var queens = 0
	var bishops = [0, 0]
	for sq in range(64):
		if absi(bd[sq]) == 5:
			queens += 1
	var adv_w = 6.0
	var cen_w = 3.0
	var ks_w = 10.0
	if style == 1:
		adv_w = 10.0
		ks_w = 4.0
	elif style == 2:
		adv_w = 3.0
		ks_w = 16.0
	elif style == 3:
		cen_w = 4.0
	elif style == 4:
		cen_w = 6.0
	var s = 0.0
	for sq in range(64):
		var p = bd[sq]
		if p == 0:
			continue
		var col = 1 if p > 0 else -1
		var t = absi(p)
		var f = sq & 7
		var r = sq >> 3
		var rr = r if col > 0 else 7 - r
		var dist = absi(f * 2 - 7) + absi(r * 2 - 7)
		var v = float(VAL[t])
		if t == 1:
			v += rr * adv_w + (7 - absi(f * 2 - 7)) * cen_w * 0.5
		elif t == 2:
			v += (14 - dist) * cen_w * 1.3
		elif t == 3:
			v += (14 - dist) * cen_w * 0.7
			bishops[0 if col > 0 else 1] += 1
		elif t == 4:
			if rr == 6:
				v += 20.0
		elif t == 5:
			v += (14 - dist) * cen_w * 0.3
		elif t == 6:
			if queens > 0:
				v -= rr * ks_w
				if rr == 0 and (f <= 2 or f >= 6):
					v += 15.0
			else:
				v += (14 - dist) * 4.0
		s += col * v
	if bishops[0] >= 2:
		s += 30.0
	if bishops[1] >= 2:
		s -= 30.0
	return int(s) * c.turn

func _order(c, moves):
	var sc = []
	for m in moves:
		var to = (m >> 6) & 63
		var s = 0
		var cap = c.b[to]
		if cap != 0:
			s = 10 * VAL[absi(cap)] - VAL[absi(c.b[m & 63])] + 10000
		elif ((m >> 15) & 7) == 2:
			s = 11000
		if ((m >> 12) & 7) == 5:
			s += 9000
		sc.append([s, m])
	sc.sort_custom(func(x, y): return x[0] > y[0])
	var out = []
	for e in sc:
		out.append(e[1])
	return out

func quiesce(c, alpha, beta, qd):
	nodes += 1
	if (nodes & 1023) == 0 and Time.get_ticks_msec() > deadline:
		stop = true
	if stop:
		return 0
	var stand = evaluate(c)
	if stand >= beta:
		return stand
	if stand > alpha:
		alpha = stand
	if qd >= qlimit:
		return alpha
	var caps = []
	for m in c.legal_moves():
		if c.b[(m >> 6) & 63] != 0 or ((m >> 15) & 7) == 2 or ((m >> 12) & 7) == 5:
			caps.append(m)
	caps = _order(c, caps)
	for m in caps:
		c.make(m)
		var sc = -quiesce(c, -beta, -alpha, qd + 1)
		c.unmake()
		if stop:
			return 0
		if sc >= beta:
			return sc
		if sc > alpha:
			alpha = sc
	return alpha

func search(c, depth, alpha, beta, ply):
	nodes += 1
	if (nodes & 1023) == 0 and Time.get_ticks_msec() > deadline:
		stop = true
	if stop:
		return 0
	if depth <= 0:
		return quiesce(c, alpha, beta, 0)
	var moves = c.legal_moves()
	if moves.is_empty():
		return (-30000 + ply) if c.in_check(c.turn) else 0
	moves = _order(c, moves)
	var best = -1000000
	for m in moves:
		c.make(m)
		var sc = -search(c, depth - 1, -beta, -alpha, ply + 1)
		c.unmake()
		if stop:
			return 0
		if sc > best:
			best = sc
		if sc > alpha:
			alpha = sc
		if alpha >= beta:
			break
	return best

func choose(c, lvl, st, tmax = -1):
	style = st
	var i = clampi(lvl - 1, 0, 8)
	qlimit = QLIM[i]
	var legal = c.legal_moves()
	if legal.is_empty():
		return -1
	if legal.size() == 1:
		return legal[0]
	if rng.randf() < BLUN[i]:
		return legal[rng.randi() % legal.size()]
	var tlim = TIME[i] if tmax < 0 else tmax
	var start = Time.get_ticks_msec()
	var cur = _order(c, legal)
	var best_m = cur[0]
	for d in range(1, DEPTH[i] + 1):
		stop = false
		deadline = (start + tlim) if d > 1 else (start + 100000000)
		var bm = cur[0]
		var best = -1000000
		var alpha = -1000000
		for m in cur:
			c.make(m)
			var sc = -search(c, d - 1, -1000000, -alpha, 1)
			c.unmake()
			if stop:
				break
			sc += rng.randi_range(-NOISE[i], NOISE[i])
			if sc > best:
				best = sc
				bm = m
			if sc > alpha:
				alpha = sc
		if stop:
			break
		best_m = bm
		cur.erase(bm)
		cur.insert(0, bm)
		if best > 25000:
			break
	return best_m

# Score every legal move (from the mover's point of view) at a fixed depth. Used by coach + review.
func score_moves(c, depth):
	var res = {}
	style = 0
	qlimit = 4
	stop = false
	deadline = Time.get_ticks_msec() + 60000
	for m in c.legal_moves():
		c.make(m)
		res[m] = -search(c, depth - 1, -1000000, 1000000, 1)
		c.unmake()
	return res

func eval_pos(c, depth):
	style = 0
	qlimit = 4
	stop = false
	deadline = Time.get_ticks_msec() + 20000
	return search(c, depth, -1000000, 1000000, 0)

# Returns a short warning if the move leaves something capturable for free / bad trade.
func hanging_note(c, m):
	var mover = c.turn
	c.make(m)
	var note = ""
	var worst = 0
	for r in c.legal_moves():
		var to = (r >> 6) & 63
		var victim = absi(c.b[to])
		if victim == 0 or victim == 6:
			continue
		var att = absi(c.b[r & 63])
		var defended = c.attacked(to, mover)
		var gain = VAL[victim] - (VAL[att] if defended else 0)
		if gain > worst and gain >= 150:
			worst = gain
			note = "Your " + ["pawn", "knight", "bishop", "rook", "queen", "king"][victim - 1] + " on " + Chess.sq_name(to) + " can be captured."
	c.unmake()
	return note
