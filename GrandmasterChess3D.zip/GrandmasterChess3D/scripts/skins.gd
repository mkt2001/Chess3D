class_name Skins
extends RefCounted
# Premium theme catalogue: board skins, piece sets and 3D environments (all selectable & combinable).

static func boards():
	return [
		{"n": "Classic Wood", "l": Color("#ecd1a0"), "d": Color("#8a5a2e"), "f": Color("#3a2312"), "m": 0.0, "r": 0.5, "e": 0.0, "a": 1.0, "tex": 1},
		{"n": "Royal Gold", "l": Color("#f6e3a1"), "d": Color("#a8761a"), "f": Color("#5b3a07"), "m": 0.85, "r": 0.28, "e": 0.0, "a": 1.0, "tex": 0},
		{"n": "Black Marble", "l": Color("#8d8f99"), "d": Color("#14151a"), "f": Color("#07070a"), "m": 0.2, "r": 0.12, "e": 0.0, "a": 1.0, "tex": 2},
		{"n": "White Marble", "l": Color("#f4f3ef"), "d": Color("#a9a8a4"), "f": Color("#c8b274"), "m": 0.1, "r": 0.14, "e": 0.0, "a": 1.0, "tex": 2},
		{"n": "Crystal Glass", "l": Color("#cfe9ff"), "d": Color("#4a7fb3"), "f": Color("#1f3a57"), "m": 0.1, "r": 0.05, "e": 0.0, "a": 0.62, "tex": 0},
		{"n": "Emerald", "l": Color("#9be7bf"), "d": Color("#0e6b47"), "f": Color("#053524"), "m": 0.4, "r": 0.18, "e": 0.0, "a": 1.0, "tex": 0},
		{"n": "Neon Grid", "l": Color("#12303f"), "d": Color("#0a0a1c"), "f": Color("#00e5ff"), "m": 0.5, "r": 0.2, "e": 0.9, "a": 1.0, "tex": 0},
		{"n": "Carbon Luxury", "l": Color("#3b3e46"), "d": Color("#17181c"), "f": Color("#c9a23a"), "m": 0.7, "r": 0.3, "e": 0.0, "a": 1.0, "tex": 0},
	]

static func pieces():
	return [
		{"n": "Classic Staunton", "w": Color("#f3e6c8"), "b": Color("#2b1c12"), "m": 0.0, "r": 0.35, "e": 0.0, "a": 1.0},
		{"n": "Royal Gold", "w": Color("#ffd76a"), "b": Color("#6a431a"), "m": 1.0, "r": 0.22, "e": 0.0, "a": 1.0},
		{"n": "Metallic Steel", "w": Color("#dfe5ee"), "b": Color("#2a2e38"), "m": 0.95, "r": 0.2, "e": 0.0, "a": 1.0},
		{"n": "Crystal", "w": Color("#d8f1ff"), "b": Color("#6b3cff"), "m": 0.1, "r": 0.05, "e": 0.0, "a": 0.72},
		{"n": "Neon Pulse", "w": Color("#7df9ff"), "b": Color("#ff3df2"), "m": 0.3, "r": 0.3, "e": 1.4, "a": 1.0},
		{"n": "Marble", "w": Color("#f5f5f2"), "b": Color("#202126"), "m": 0.15, "r": 0.15, "e": 0.0, "a": 1.0},
	]

static func envs():
	return [
		{"n": "Royal Palace", "top": Color("#2a1a05"), "hor": Color("#c99a3a"), "fl": Color("#6b4a1a"), "lc": Color("#fff0cf"), "le": 1.3, "amb": Color("#7a6a4a"), "ae": 1.0, "stars": false, "torch": false},
		{"n": "Medieval Castle", "top": Color("#1b1f2a"), "hor": Color("#5b5f6c"), "fl": Color("#3a3d44"), "lc": Color("#ffd9a0"), "le": 1.0, "amb": Color("#4a4f5c"), "ae": 0.9, "stars": false, "torch": true},
		{"n": "Space Chess", "top": Color("#000005"), "hor": Color("#0b0b2a"), "fl": Color("#0a0a1c"), "lc": Color("#b8c8ff"), "le": 1.1, "amb": Color("#2a2f5a"), "ae": 1.0, "stars": true, "torch": false},
		{"n": "Forest", "top": Color("#5fa8d3"), "hor": Color("#cfe8c0"), "fl": Color("#2d5a2a"), "lc": Color("#fff3d0"), "le": 1.5, "amb": Color("#8aa88a"), "ae": 1.0, "stars": false, "torch": false},
		{"n": "Modern Room", "top": Color("#cfd6e0"), "hor": Color("#f1f3f6"), "fl": Color("#8b9097"), "lc": Color("#ffffff"), "le": 1.2, "amb": Color("#aab2bf"), "ae": 1.0, "stars": false, "torch": false},
		{"n": "Dark AMOLED", "top": Color("#000000"), "hor": Color("#05050a"), "fl": Color("#050507"), "lc": Color("#bcd0ff"), "le": 0.9, "amb": Color("#222a40"), "ae": 1.0, "stars": false, "torch": false},
	]
