class_name PieceFactory
extends RefCounted
# Procedural genuine 3D chess pieces (lathe-turned meshes + modelled parts). No external assets needed.

static var _cache = {}

static func arc(cx, cy, rx, ry, a0, a1, n):
	var out = []
	for i in range(n + 1):
		var a = deg_to_rad(a0 + (a1 - a0) * float(i) / n)
		out.append(Vector2(cx + rx * cos(a), cy + ry * sin(a)))
	return out

static func base():
	return [Vector2(0, 0), Vector2(0.36, 0), Vector2(0.38, 0.03), Vector2(0.38, 0.08), Vector2(0.33, 0.12), Vector2(0.30, 0.16)]

static func _tri(st, a, b, c, na, nb, nc):
	st.set_normal(na)
	st.add_vertex(a)
	st.set_normal(nb)
	st.add_vertex(b)
	st.set_normal(nc)
	st.add_vertex(c)

static func lathe(pts, seg = 28):
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var n = pts.size()
	var segn = []
	for j in range(n - 1):
		var t = pts[j + 1] - pts[j]
		if t.length() < 0.0001:
			segn.append(Vector2(1, 0))
		else:
			segn.append(Vector2(t.y, -t.x).normalized())
	for j in range(n - 1):
		var n0 = segn[j]
		var n1 = segn[j]
		if j > 0 and segn[j - 1].dot(segn[j]) > 0.7:
			n0 = (segn[j - 1] + segn[j]).normalized()
		if j < n - 2 and segn[j + 1].dot(segn[j]) > 0.7:
			n1 = (segn[j + 1] + segn[j]).normalized()
		for i in range(seg):
			var a0 = TAU * i / seg
			var a1 = TAU * (i + 1) / seg
			var c0 = Vector2(cos(a0), sin(a0))
			var c1 = Vector2(cos(a1), sin(a1))
			var va = Vector3(pts[j].x * c0.x, pts[j].y, pts[j].x * c0.y)
			var vb = Vector3(pts[j].x * c1.x, pts[j].y, pts[j].x * c1.y)
			var vc = Vector3(pts[j + 1].x * c1.x, pts[j + 1].y, pts[j + 1].x * c1.y)
			var vd = Vector3(pts[j + 1].x * c0.x, pts[j + 1].y, pts[j + 1].x * c0.y)
			var na = Vector3(n0.x * c0.x, n0.y, n0.x * c0.y)
			var nb = Vector3(n0.x * c1.x, n0.y, n0.x * c1.y)
			var nc = Vector3(n1.x * c1.x, n1.y, n1.x * c1.y)
			var nd = Vector3(n1.x * c0.x, n1.y, n1.x * c0.y)
			_tri(st, va, vb, vc, na, nb, nc)
			_tri(st, va, vc, vd, na, nc, nd)
	return st.commit()

static func _lathe_cached(key, pts):
	if not _cache.has(key):
		_cache[key] = lathe(pts)
	return _cache[key]

static func _mi(root, mesh, mat, pos = Vector3.ZERO, rot = Vector3.ZERO):
	var m = MeshInstance3D.new()
	m.mesh = mesh
	m.material_override = mat
	m.position = pos
	m.rotation_degrees = rot
	root.add_child(m)
	return m

static func _box(root, mat, size, pos, rot = Vector3.ZERO):
	var bm = BoxMesh.new()
	bm.size = size
	return _mi(root, bm, mat, pos, rot)

static func _ball(root, mat, r, pos):
	var s = SphereMesh.new()
	s.radius = r
	s.height = r * 2.0
	s.radial_segments = 16
	s.rings = 8
	return _mi(root, s, mat, pos)

static func build(t, mat):
	var root = Node3D.new()
	var pts = base()
	if t == 1:
		pts += [Vector2(0.2, 0.24), Vector2(0.13, 0.38), Vector2(0.13, 0.44), Vector2(0.22, 0.47), Vector2(0.22, 0.51), Vector2(0.13, 0.54)]
		pts += arc(0, 0.7, 0.17, 0.17, -50, 90, 10)
		_mi(root, _lathe_cached(1, pts), mat)
	elif t == 4:
		pts += [Vector2(0.25, 0.22), Vector2(0.2, 0.42), Vector2(0.2, 0.6), Vector2(0.3, 0.66), Vector2(0.3, 0.72), Vector2(0.34, 0.76), Vector2(0.34, 0.86), Vector2(0.27, 0.86), Vector2(0.27, 0.8), Vector2(0, 0.8)]
		_mi(root, _lathe_cached(4, pts), mat)
		for i in range(6):
			var a = TAU * i / 6.0
			_box(root, mat, Vector3(0.14, 0.1, 0.12), Vector3(cos(a) * 0.3, 0.91, sin(a) * 0.3), Vector3(0, -rad_to_deg(a), 0))
	elif t == 3:
		pts += [Vector2(0.22, 0.24), Vector2(0.14, 0.44), Vector2(0.14, 0.5), Vector2(0.22, 0.54), Vector2(0.22, 0.58), Vector2(0.14, 0.62)]
		pts += arc(0, 0.93, 0.19, 0.3, -75, 90, 12)
		_mi(root, _lathe_cached(3, pts), mat)
		_ball(root, mat, 0.065, Vector3(0, 1.26, 0))
	elif t == 5:
		pts += [Vector2(0.25, 0.24), Vector2(0.15, 0.5), Vector2(0.15, 0.62), Vector2(0.23, 0.68), Vector2(0.23, 0.72), Vector2(0.16, 0.76), Vector2(0.2, 0.9), Vector2(0.3, 1.12), Vector2(0.32, 1.2), Vector2(0.28, 1.24), Vector2(0, 1.24)]
		_mi(root, _lathe_cached(5, pts), mat)
		for i in range(8):
			var a = TAU * i / 8.0
			_ball(root, mat, 0.055, Vector3(cos(a) * 0.27, 1.27, sin(a) * 0.27))
		_ball(root, mat, 0.09, Vector3(0, 1.31, 0))
	elif t == 6:
		pts += [Vector2(0.25, 0.24), Vector2(0.15, 0.5), Vector2(0.15, 0.64), Vector2(0.24, 0.7), Vector2(0.24, 0.74), Vector2(0.17, 0.78), Vector2(0.2, 0.95), Vector2(0.28, 1.18), Vector2(0.28, 1.26), Vector2(0.2, 1.3), Vector2(0, 1.3)]
		_mi(root, _lathe_cached(6, pts), mat)
		_box(root, mat, Vector3(0.09, 0.34, 0.09), Vector3(0, 1.47, 0))
		_box(root, mat, Vector3(0.26, 0.09, 0.09), Vector3(0, 1.5, 0))
	else:
		pts += [Vector2(0.26, 0.2), Vector2(0.26, 0.26), Vector2(0, 0.26)]
		_mi(root, _lathe_cached(2, pts), mat)
		_box(root, mat, Vector3(0.3, 0.62, 0.34), Vector3(0, 0.57, 0.02), Vector3(-14, 0, 0))
		_box(root, mat, Vector3(0.26, 0.28, 0.5), Vector3(0, 0.98, -0.16), Vector3(-18, 0, 0))
		_box(root, mat, Vector3(0.2, 0.2, 0.26), Vector3(0, 0.9, -0.46), Vector3(-24, 0, 0))
		_box(root, mat, Vector3(0.07, 0.5, 0.1), Vector3(0, 0.9, 0.2), Vector3(-14, 0, 0))
		var pm = PrismMesh.new()
		pm.size = Vector3(0.09, 0.15, 0.06)
		_mi(root, pm, mat, Vector3(0.08, 1.22, -0.02))
		_mi(root, pm, mat, Vector3(-0.08, 1.22, -0.02))
	return root
