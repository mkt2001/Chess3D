class_name Board3D
extends Node3D
# 3D board, pieces, environments, orbit camera, tap picking and move animations.

signal square_tapped(sq)

var cam
var sun
var fill
var wenv
var env
var sky_mat
var piece_root
var marks
var squares = []
var pieces = {}
var floor_mi
var frame_mi
var base_mi
var stars
var torches = []
var mat_w
var mat_b
var mat_l
var mat_d
var cur_b = []

var yaw = 0.0
var pitch = 0.9
var dist = 15.0
var look = Vector3.ZERO
var t_yaw = 0.0
var t_pitch = 0.9
var t_dist = 15.0
var t_look = Vector3.ZERO
var orbit = false
var flipped = false
var input_on = false
var view_i = 0
var touches = {}
var tap_ok = true
var tap_start = Vector2.ZERO
var tap_time = 0
var _time = 0.0

func _ready():
	env = Environment.new()
	sky_mat = ProceduralSkyMaterial.new()
	var sky = Sky.new()
	sky.sky_material = sky_mat
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.glow_enabled = true
	wenv = WorldEnvironment.new()
	wenv.environment = env
	add_child(wenv)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, 35, 0)
	sun.shadow_enabled = true
	add_child(sun)
	fill = DirectionalLight3D.new()
	fill.rotation_degrees = Vector3(-30, -145, 0)
	fill.light_energy = 0.35
	add_child(fill)
	cam = Camera3D.new()
	cam.keep_aspect = Camera3D.KEEP_WIDTH
	cam.fov = 52
	cam.far = 200
	add_child(cam)
	piece_root = Node3D.new()
	add_child(piece_root)
	marks = Node3D.new()
	add_child(marks)
	_build_board()
	_build_extras()
	set_skin(0, 0, 0)
	_update_cam(1.0)

func _build_board():
	for sq in range(64):
		var mi = MeshInstance3D.new()
		var bm = BoxMesh.new()
		bm.size = Vector3(1, 0.2, 1)
		mi.mesh = bm
		mi.position = sq_pos(sq) + Vector3(0, -0.1, 0)
		add_child(mi)
		squares.append(mi)
	frame_mi = MeshInstance3D.new()
	var fm = BoxMesh.new()
	fm.size = Vector3(9.2, 0.3, 9.2)
	frame_mi.mesh = fm
	frame_mi.position = Vector3(0, -0.2, 0)
	add_child(frame_mi)
	base_mi = MeshInstance3D.new()
	var bm2 = BoxMesh.new()
	bm2.size = Vector3(9.8, 0.25, 9.8)
	base_mi.mesh = bm2
	base_mi.position = Vector3(0, -0.45, 0)
	add_child(base_mi)
	floor_mi = MeshInstance3D.new()
	var cm = CylinderMesh.new()
	cm.top_radius = 22.0
	cm.bottom_radius = 22.0
	cm.height = 0.4
	floor_mi.mesh = cm
	floor_mi.position = Vector3(0, -0.8, 0)
	add_child(floor_mi)

func _build_extras():
	var mm = MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	var sm = SphereMesh.new()
	sm.radius = 0.09
	sm.height = 0.18
	sm.radial_segments = 6
	sm.rings = 3
	mm.mesh = sm
	mm.instance_count = 240
	var rng = RandomNumberGenerator.new()
	rng.seed = 7
	for i in range(240):
		var d = Vector3(rng.randf_range(-1, 1), rng.randf_range(0.0, 1.0), rng.randf_range(-1, 1)).normalized() * rng.randf_range(35, 60)
		mm.set_instance_transform(i, Transform3D(Basis(), d))
	stars = MultiMeshInstance3D.new()
	stars.multimesh = mm
	var sm2 = StandardMaterial3D.new()
	sm2.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sm2.albedo_color = Color(1, 1, 1)
	stars.material_override = sm2
	add_child(stars)
	for p in [Vector3(5.5, 2.6, 5.5), Vector3(-5.5, 2.6, 5.5), Vector3(5.5, 2.6, -5.5), Vector3(-5.5, 2.6, -5.5)]:
		var o = OmniLight3D.new()
		o.position = p
		o.light_color = Color("#ff9a3c")
		o.omni_range = 12.0
		o.light_energy = 1.4
		add_child(o)
		torches.append(o)

func _noise_tex(freq):
	var n = FastNoiseLite.new()
	n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	n.frequency = freq
	var t = NoiseTexture2D.new()
	t.noise = n
	t.width = 256
	t.height = 256
	t.seamless = true
	var g = Gradient.new()
	g.set_color(0, Color(0.68, 0.68, 0.68))
	g.set_color(1, Color(1, 1, 1))
	t.color_ramp = g
	return t

func _mat(col, metal, rough, emit, alpha, tex = 0):
	var m = StandardMaterial3D.new()
	m.albedo_color = col
	m.metallic = metal
	m.roughness = rough
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	if emit > 0.0:
		m.emission_enabled = true
		m.emission = col
		m.emission_energy_multiplier = emit
	if alpha < 1.0:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.albedo_color.a = alpha
	if tex == 1:
		m.albedo_texture = _noise_tex(0.03)
	elif tex == 2:
		m.albedo_texture = _noise_tex(0.012)
	return m

func set_skin(bi, pi, ei):
	var B = Skins.boards()[bi]
	var P = Skins.pieces()[pi]
	var E = Skins.envs()[ei]
	mat_l = _mat(B.l, B.m, B.r, B.e, B.a, B.tex)
	mat_d = _mat(B.d, B.m, B.r, B.e, B.a, B.tex)
	for sq in range(64):
		squares[sq].material_override = mat_d if ((sq & 7) + (sq >> 3)) % 2 == 0 else mat_l
	frame_mi.material_override = _mat(B.f, 0.6, 0.3, 0.6 if B.e > 0.0 else 0.0, 1.0)
	base_mi.material_override = _mat(B.f.darkened(0.4), 0.3, 0.5, 0.0, 1.0)
	mat_w = _mat(P.w, P.m, P.r, P.e, P.a)
	mat_b = _mat(P.b, P.m, P.r, P.e, P.a)
	floor_mi.material_override = _mat(E.fl, 0.25, 0.35, 0.0, 1.0)
	sky_mat.sky_top_color = E.top
	sky_mat.sky_horizon_color = E.hor
	sky_mat.ground_bottom_color = E.fl.darkened(0.5)
	sky_mat.ground_horizon_color = E.hor
	env.ambient_light_color = E.amb
	env.ambient_light_energy = E.ae
	sun.light_color = E.lc
	sun.light_energy = E.le
	stars.visible = E.stars
	for o in torches:
		o.visible = E.torch

func sq_pos(sq):
	return Vector3((sq & 7) - 3.5, 0.0, 3.5 - (sq >> 3))

func _spawn(sq, p):
	var node = PieceFactory.build(absi(p), mat_w if p > 0 else mat_b)
	node.position = sq_pos(sq)
	node.set_meta("col", 1 if p > 0 else -1)
	if p < 0 and absi(p) == 2:
		node.rotation.y = PI
	piece_root.add_child(node)
	pieces[sq] = node
	return node

func show_position(c):
	for ch in piece_root.get_children():
		ch.queue_free()
	pieces.clear()
	cur_b = c.b.duplicate()
	for sq in range(64):
		if cur_b[sq] != 0:
			_spawn(sq, cur_b[sq])

func set_blind(on):
	piece_root.visible = not on

func _kill(node):
	var tw = create_tween()
	tw.tween_interval(0.28)
	tw.tween_property(node, "scale", Vector3(0.01, 0.01, 0.01), 0.25)
	tw.tween_callback(node.queue_free)

func animate_move(m):
	var from = m & 63
	var to = (m >> 6) & 63
	var promo = (m >> 12) & 7
	var flag = (m >> 15) & 7
	var node = pieces.get(from)
	if node == null:
		return
	var col = node.get_meta("col")
	pieces.erase(from)
	var victim = pieces.get(to)
	if flag == 2:
		var vs = to - 8 * col
		victim = pieces.get(vs)
		pieces.erase(vs)
	elif victim != null:
		pieces.erase(to)
	if victim != null:
		_kill(victim)
		shake(0.1)
	pieces[to] = node
	var p0 = node.position
	var p1 = sq_pos(to)
	var lift = 0.9 if (cur_b.size() == 64 and absi(cur_b[from]) == 2) else 0.45
	var tw = create_tween()
	tw.tween_property(node, "position", Vector3(p0.x, lift, p0.z), 0.12)
	tw.tween_property(node, "position", Vector3(p1.x, lift, p1.z), 0.3).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(node, "position", p1, 0.12).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	if flag == 3 or flag == 4:
		var rf = to + 1 if flag == 3 else to - 2
		var rt = to - 1 if flag == 3 else to + 1
		var rook = pieces.get(rf)
		if rook != null:
			pieces.erase(rf)
			pieces[rt] = rook
			var tr = create_tween()
			tr.tween_property(rook, "position", sq_pos(rt), 0.45).set_trans(Tween.TRANS_SINE)
	if promo != 0:
		tw.tween_callback(func(): _promote(to, promo * col))
	# keep cur_b roughly in sync so lift height can be derived
	if from < cur_b.size():
		cur_b[to] = cur_b[from] if promo == 0 else promo * col
		cur_b[from] = 0

func _promote(sq, p):
	var old = pieces.get(sq)
	if old != null:
		old.queue_free()
	var n = _spawn(sq, p)
	n.scale = Vector3(0.1, 0.1, 0.1)
	var tw = create_tween()
	tw.tween_property(n, "scale", Vector3.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

func shake(a = 0.12):
	var tw = create_tween()
	tw.tween_method(func(v): cam.h_offset = v * sin(v * 90.0), a, 0.0, 0.3)

func pulse():
	var tw = create_tween()
	tw.tween_property(cam, "fov", 45.0, 0.2)
	tw.tween_property(cam, "fov", 52.0, 0.4)

func mate_cinematic(king_sq):
	var k = pieces.get(king_sq)
	if k != null:
		var tw = create_tween()
		tw.tween_interval(0.5)
		tw.tween_property(k, "rotation:z", PI * 0.5, 0.8).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
		tw.parallel().tween_property(k, "position:y", 0.2, 0.8)
	t_look = sq_pos(king_sq)
	t_dist = 8.0
	t_pitch = 0.6
	orbit = true

func clear_marks():
	for c in marks.get_children():
		c.queue_free()

func _mark(sq, col, kind):
	var mi = MeshInstance3D.new()
	if kind == "sq":
		var bm = BoxMesh.new()
		bm.size = Vector3(0.96, 0.02, 0.96)
		mi.mesh = bm
	else:
		var cm = CylinderMesh.new()
		var r = 0.16 if kind == "dot" else 0.44
		cm.top_radius = r
		cm.bottom_radius = r
		cm.height = 0.02
		cm.radial_segments = 32
		mi.mesh = cm
	var m = StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_color = col
	mi.material_override = m
	mi.position = sq_pos(sq) + Vector3(0, 0.012, 0)
	marks.add_child(mi)

func show_marks(sel, targets, last, chk, hint):
	clear_marks()
	if last[0] >= 0:
		_mark(last[0], Color(1.0, 0.85, 0.2, 0.35), "sq")
		_mark(last[1], Color(1.0, 0.85, 0.2, 0.45), "sq")
	if hint[0] >= 0:
		_mark(hint[0], Color(0.2, 0.6, 1.0, 0.55), "sq")
		_mark(hint[1], Color(0.2, 0.9, 1.0, 0.65), "sq")
	if chk >= 0:
		_mark(chk, Color(1.0, 0.15, 0.2, 0.6), "sq")
	if sel >= 0:
		_mark(sel, Color(0.3, 1.0, 0.6, 0.5), "sq")
	for t in targets:
		if t[1]:
			_mark(t[0], Color(1.0, 0.3, 0.3, 0.55), "ring")
		else:
			_mark(t[0], Color(0.3, 1.0, 0.7, 0.8), "dot")

# ---------- camera ----------
func showcase(on):
	orbit = on
	input_on = not on
	if on:
		t_dist = 15.0
		t_pitch = 0.55
		t_look = Vector3(0, 0, 3.4)
	else:
		t_look = Vector3(0, 0, 0.6)
		set_view(0)

func set_flipped(f):
	flipped = f
	t_yaw = PI if f else 0.0
	yaw = t_yaw

func flip():
	flipped = not flipped
	t_yaw = (PI if flipped else 0.0)

func set_view(i):
	view_i = i % 5
	orbit = false
	var base_yaw = PI if flipped else 0.0
	match view_i:
		0:
			t_yaw = base_yaw
			t_pitch = 0.9
			t_dist = 12.0
		1:
			t_yaw = base_yaw
			t_pitch = 1.5
			t_dist = 12.5
		2:
			t_yaw = base_yaw
			t_pitch = 0.2
			t_dist = 14.0
		3:
			t_yaw = base_yaw + PI * 0.25
			t_pitch = 0.65
			t_dist = 12.5
		4:
			t_pitch = 0.55
			t_dist = 11.0
			orbit = true
	t_look = Vector3(0, 0, 0.6)

func cycle_view():
	set_view(view_i + 1)
	return ["Standard", "Top-down", "Side view", "Isometric", "Cinematic"][view_i]

func _update_cam(delta):
	var k = 1.0 - exp(-8.0 * delta)
	yaw = lerp_angle(yaw, t_yaw, k)
	pitch = lerpf(pitch, t_pitch, k)
	dist = lerpf(dist, t_dist, k)
	look = look.lerp(t_look, k)
	cam.position = look + Vector3(sin(yaw) * cos(pitch), sin(pitch), cos(yaw) * cos(pitch)) * dist
	cam.look_at(look, Vector3.UP)

func _process(delta):
	_time += delta
	if orbit:
		t_yaw += delta * 0.22
	_update_cam(delta)
	for i in range(torches.size()):
		torches[i].light_energy = 1.4 + 0.35 * sin(_time * 9.0 + i * 2.0)

# ---------- input ----------
func pick(pos):
	var o = cam.project_ray_origin(pos)
	var d = cam.project_ray_normal(pos)
	var hit = Plane(Vector3.UP, 0.35).intersects_ray(o, d)
	if hit == null:
		return -1
	var f = int(floor(hit.x + 4.0))
	var r = int(floor(4.0 - hit.z))
	if f < 0 or f > 7 or r < 0 or r > 7:
		return -1
	return r * 8 + f

func _unhandled_input(event):
	if event is InputEventScreenTouch:
		if event.pressed:
			touches[event.index] = event.position
			if touches.size() == 1:
				tap_ok = true
				tap_start = event.position
				tap_time = Time.get_ticks_msec()
			else:
				tap_ok = false
		else:
			var was_single = touches.size() == 1
			touches.erase(event.index)
			if was_single and tap_ok and input_on and Time.get_ticks_msec() - tap_time < 500:
				square_tapped.emit(pick(event.position))
	elif event is InputEventScreenDrag:
		var prev = touches.get(event.index, event.position)
		touches[event.index] = event.position
		if touches.size() == 1:
			if event.position.distance_to(tap_start) > 24.0:
				tap_ok = false
			if not tap_ok:
				orbit = false
				t_yaw -= event.relative.x * 0.006
				t_pitch = clampf(t_pitch + event.relative.y * 0.005, 0.15, 1.5)
		elif touches.size() == 2:
			var keys = touches.keys()
			var a = touches[keys[0]]
			var b = touches[keys[1]]
			var old_a = a - (event.relative if event.index == keys[0] else Vector2.ZERO)
			var old_b = b - (event.relative if event.index == keys[1] else Vector2.ZERO)
			var delta = a.distance_to(b) - old_a.distance_to(old_b)
			t_dist = clampf(t_dist - delta * 0.02, 7.0, 20.0)
