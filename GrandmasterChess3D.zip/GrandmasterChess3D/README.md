# 3D Grandmaster Chess (Godot 4.3, Android)

Upload ALL files of this folder (including the hidden `.github` folder) to a GitHub repo root.
Actions tab -> "Build Android APK" runs automatically on push. The APK appears in
Releases and as a build artifact (3DGrandmasterChess-apk).

Built-in: real 3D board + procedural 3D pieces, 8 board themes, 6 piece sets, 6 environments,
own alpha-beta AI (9 levels, 5 styles), coach, game review, academy, puzzles, guess-the-move,
Chess960, blindfold, 2-player.
